package com.skf.style;
/*
 * schamanskiy gennadiy
 * superslon74@gmail.com
 * 
 * */
import java.util.ArrayList;
import java.util.List;

import com.skf.vibracon.selection.R;

import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;

public class SKF_list_controller implements OnClickListener {

	protected List<View> m_items;
	protected ViewGroup m_listContainer;
	protected LayoutInflater m_layoutInflater;
	protected SKFListOnClickListener m_onClickListener;

	public SKF_list_controller(LayoutInflater layoutInflater,
			ViewGroup listContainer, SKFListOnClickListener onClickListener) {
		m_items = new ArrayList<View>();
		m_listContainer = listContainer;
		m_layoutInflater = layoutInflater;
		m_onClickListener = onClickListener;
	}

	public int addView(int resourceId) {
		return addView(m_layoutInflater.inflate(resourceId, null));
	}

	public int addView(View item) {
		m_items.add(item);
		return (m_items.size() - 1);
	}

	public void createList() {
		applyChanges(true);
	}

	public void createMenu() {
		applyChanges(false);
	}

	public void clear()
	{
		m_listContainer.removeAllViews();
		m_items.clear();
	}
	
	public int size() {
		return m_items.size();
	}

	public View getItem(int position) {
		return m_items.get(position);
	}

	protected void applyChanges(boolean useListStyle) {

		final int[][] item_bg = {
				{ R.drawable.skf_menu_item_single,
						R.drawable.skf_menu_item_top,
						R.drawable.skf_menu_item_middle,
						R.drawable.skf_menu_item_bottom },
				{ R.drawable.skf_menu_item2_single,
						R.drawable.skf_menu_item2_top,
						R.drawable.skf_menu_item2_middle,
						R.drawable.skf_menu_item2_bottom } };
		final int cnt = m_items.size();

		for (int i = 0; i < cnt; ++i) {

			int resInd = (1 == cnt) ? 0 : ((0 == i) ? 1 : ((cnt - 1 == i) ? 3
					: 2));
			int styleInd = useListStyle ? (i % 2) : 0;

			View v = m_items.get(i);
			v.setBackgroundResource(item_bg[styleInd][resInd]);
			v.setTag(new SKFListItemTag(i));
			v.setOnClickListener(this);
			m_listContainer.addView(v);
		}
	}

	public void onClick(View v) {
		if (null != m_onClickListener) {

			boolean clicked = false;
			Object tag = v.getTag();
			if (null != tag) {
				if (tag instanceof SKFListItemTag) {
					m_onClickListener.SKF_OnListItemClick(m_listContainer, v,
							((SKFListItemTag) tag).Index);
					clicked = true;
				}

				if (!clicked) {
					m_onClickListener.SKF_OnListItemClick(m_listContainer, v,
							-1);
				}
			}
		}
	}

	public interface SKFListOnClickListener {
		void SKF_OnListItemClick(View listContainer, View v, int ItemIndex);
	}

	private class SKFListItemTag {
		public int Index;

		public SKFListItemTag(int index) {
			this.Index = index;
		}
	}

}
