package com.skf.style;
/*
 * schamanskiy gennadiy
 * superslon74@gmail.com
 * 
 * */
import com.skf.vibracon.selection.R;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.drawable.PaintDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RectShape;
import android.util.AttributeSet;
import android.widget.LinearLayout;

public class SKF_gradient_bar extends LinearLayout {

	protected int color_border_top;
	protected int color_border_bottom;
	protected int color_gradient_start;
	protected int color_gradient_end;
	protected float border_width;

	public SKF_gradient_bar(Context context) {
		super(context);
	}

	public SKF_gradient_bar(Context context, AttributeSet attrs) {
		super(context, attrs);

	}

	@Override
	protected void onFinishInflate() {

		super.onFinishInflate();

		setupBGParams();
		
		setupBGGradient();
	}

	protected void setupBGParams() {
		Resources Rs = getResources();
		border_width = Rs.getDimension(R.dimen.skf_gradient_bar_border);
		color_border_top = Rs.getColor(R.color.skf_gradientbar_border_top);
		color_border_bottom = Rs
				.getColor(R.color.skf_gradientbar_border_bottom);
		color_gradient_start = Rs
				.getColor(R.color.skf_gradientbar_gradient_start);
		color_gradient_end = Rs.getColor(R.color.skf_gradientbar_gradient_end);

	}

	protected void setupBGGradient() {
		ShapeDrawable.ShaderFactory sf = new ShapeDrawable.ShaderFactory() {
			@Override
			public Shader resize(int width, int height) {
				int colors[] = null;
				float positons[] = null;

				if (height < (border_width * 2 + 4)) {
					colors = new int[] { color_border_top, color_border_bottom };
					positons = new float[] { 0, 1 };
				} else {
					final float th_border = border_width / height;
					final float mr_gradient = (border_width + 1) / height;

					colors = new int[] { color_border_top, color_border_top,
							color_gradient_start, color_gradient_end,
							color_border_bottom, color_border_bottom };
					positons = new float[] { 0, th_border, mr_gradient,
							1 - mr_gradient, 1 - th_border, 1 };

				}

				LinearGradient lg = new LinearGradient(0, 0, 0, height, colors,
						positons, Shader.TileMode.CLAMP);
				return lg;
			}
		};

		PaintDrawable p = new PaintDrawable();
		p.setShape(new RectShape());
		p.setShaderFactory(sf);
		setBackgroundDrawable(p);
	}

}
