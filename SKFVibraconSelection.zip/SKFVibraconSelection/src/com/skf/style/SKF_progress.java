package com.skf.style;
/*
 * schamanskiy gennadiy
 * superslon74@gmail.com
 * 
 * */
import com.skf.vibracon.selection.R;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.AttributeSet;
import android.widget.ProgressBar;

public class SKF_progress extends ProgressBar {

	public SKF_progress(Context context) {
		super(context);
	}

	public SKF_progress(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public SKF_progress(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	@Override
	public synchronized void setProgress(int progress) {
		super.setProgress(progress);

		// the setProgress super will not change the details of the progress bar
		// anymore so we need to force an update to redraw the progress bar
		invalidate();
	}

	@Override
	protected synchronized void onDraw(Canvas canvas) {
		// update the size of the progress bar and overlay
		updateProgressBar();

		// paint the changes to the canvas
		super.onDraw(canvas);
	}

	private float getScale(int progress) {
		float scale = getMax() > 0 ? (float) progress / (float) getMax() : 0;

		return scale;
	}

	/**
	 * Instead of using clipping regions to uncover the progress bar as the
	 * progress increases we increase the drawable regions for the progress bar
	 * and pattern overlay. Doing this gives us greater control and allows us to
	 * show the rounded cap on the progress bar.
	 */
	private void updateProgressBar() {
		Drawable progressDrawable = getProgressDrawable();

		if (progressDrawable != null
				&& progressDrawable instanceof LayerDrawable) {
			LayerDrawable d = (LayerDrawable) progressDrawable;

			final float scale = getScale(getProgress());

			// get the progress bar and update it's size
			Drawable progressBar = d
					.findDrawableByLayerId(android.R.id.progress);

			
			final float border = getResources().getDimension(
					 R.dimen.skf_progress_border);
			final float width = d.getBounds().right - d.getBounds().left;

			if (progressBar != null) {
				Rect progressBarBounds = progressBar.getBounds();

				final float radius = ((float) progressBarBounds.bottom
						- (float) progressBarBounds.top - border * 2.0f) * 0.5f;

				progressBarBounds.left = (int) (border);
				progressBarBounds.right = (int) (border + radius * 2
						+ (width - 2 * (radius + border)) * scale + 0.5f);
				progressBarBounds.top = progressBarBounds.top + (int) border;
				progressBarBounds.bottom = progressBarBounds.bottom
						- (int) border;
				progressBar.setBounds(progressBarBounds);
			}
		}
	}
}