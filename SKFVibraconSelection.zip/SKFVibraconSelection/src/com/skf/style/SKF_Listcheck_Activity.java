package com.skf.style;
/*
superslon74@gmail.com
skype - superslon74
schamanskij gennadij aleksandrovich
*/

import com.skf.style.SKF_list_controller.SKFListOnClickListener;
import com.skf.vibracon.selection.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

public class SKF_Listcheck_Activity extends Activity implements
		SKFListOnClickListener {

	public final static String skf_Caption = "Caption";
	public final static String skf_Items = "Items";
	public final static String skf_Selected = "Selected";

	protected SKF_list_controller m_ListController;
	protected int selected;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.skf_listcheck);

		((TextView) findViewById(R.id.skf_topbar_caption))
				.setText(getCaption());

		selected = getSelected();

		m_ListController = new SKF_list_controller(getLayoutInflater(),
				(ViewGroup) findViewById(R.id.skf_listcheck_content), this);

		createList(getItems());
	}

	protected String getCaption() {
		final Intent I = getIntent();
		return (I.hasExtra(skf_Caption)) ? I.getStringExtra(skf_Caption) : "";
	}

	protected int getSelected() {
		final Intent I = getIntent();
		return I.getIntExtra(skf_Selected, -1);
	}

	protected String[] getItems() {
		final Intent I = getIntent();
		return I.getStringArrayExtra(skf_Items);
	}

	protected void createList(String[] items) {

		LayoutInflater li = getLayoutInflater();
		final int len = items.length;

		for (int i = 0; i < len; ++i) {
			View item = li.inflate(R.layout.skf_listcheck_item, null);
			TextView text = (TextView) item
					.findViewById(R.id.skf_listcheck_item_caption);
			ImageView img = (ImageView) item
					.findViewById(R.id.skf_listcheck_item_check);

			text.setText(items[i]);
			img.setVisibility((selected == i) ? View.VISIBLE : View.GONE);
			onItemCustomized(i, item, text, img);
			m_ListController.addView(item);
		}
		m_ListController.createList();

	}

	protected void onItemCustomized(int position, View item, TextView text,
			ImageView img) {
	}

	protected void doClick(int ItemIndex) {
		Intent I = new Intent();
		I.putExtra(skf_Selected, ItemIndex);
		setResult(RESULT_OK, I);
		finish();
	}

	public void SKF_OnListItemClick(View listContainer, View v, int ItemIndex) {
		boolean ok = (ItemIndex >= 0) && (ItemIndex != selected);
		if (ok) {
			doClick(ItemIndex);
		} else {
			setResult(RESULT_CANCELED);
			finish();
		}
	}

}
