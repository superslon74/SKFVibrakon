package com.skf.style;
/*
superslon74@gmail.com
skype - superslon74
schamanskij gennadij aleksandrovich
*/

import com.skf.vibracon.selection.R;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class SKF_Listarrow_Activity extends SKF_Listcheck_Activity {
	
	@Override
	protected void onItemCustomized(int position, View item, TextView text,
			ImageView img) {
		img.setImageResource(R.drawable.skf_menu_item_arrow_selector);
		img.setVisibility(View.VISIBLE);
	}

	@Override
	protected int getSelected() {
		return -1;
	}
	

}
