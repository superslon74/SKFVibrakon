package com.skf.style;
/*
 * schamanskiy gennadiy
 * superslon74@gmail.com
 * 
 * */
import java.util.ArrayList;
import java.util.List;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.ImageView;

import com.skf.style.SKF_list_controller;
import com.skf.style.SKF_list_controller.SKFListOnClickListener;
import com.skf.vibracon.selection.R;
public class SKF_list_controller_simple {

	public static final int IMG_NONE = -1;
	public static final int IMG_CHECK = 0;
	public static final int IMG_ARROW = 1;

	private SKF_list_controller m_list_controller;
	private List<SimpleItem> m_items;

	public SKF_list_controller_simple(LayoutInflater layoutInflater,
			ViewGroup listContainer, SKFListOnClickListener onClickListener) {
		m_list_controller = new SKF_list_controller(layoutInflater,
				listContainer, onClickListener);
		m_items = new ArrayList<SimpleItem>();
	}

	public SimpleItem addItem(String Caption, boolean Clickable, int ImgType) {
		SimpleItem item = new SimpleItem(Caption, Clickable, ImgType);
		m_items.add(item);
		return item;
	}

	public void addItems(String[] Captions, boolean Clickable, int ImgType) {
		for (int i = 0, l = Captions.length; i < l; ++i) {
			m_items.add(new SimpleItem(Captions[i], Clickable, ImgType));
		}
	}

	public void addItems(List<String> Captions, boolean Clickable, int ImgType) {
		for (int i = 0, l = Captions.size(); i < l; ++i) {
			m_items.add(new SimpleItem(Captions.get(i), Clickable, ImgType));
		}
	}

	public void clear() {
		m_items.clear();
		m_list_controller.clear();
	}

	private void updateView(View v, int itemIndex) {
		SimpleItem item = m_items.get(itemIndex);
		v.setClickable(item.clickable);
		((TextView) v.findViewById(R.id.skf_listcheck_item_caption))
				.setText(item.caption);
		ImageView img = (ImageView) v
				.findViewById(R.id.skf_listcheck_item_check);
		switch (item.imgType) {
		case IMG_ARROW:
			img.setVisibility(View.VISIBLE);
			img.setImageResource(R.drawable.skf_menu_item_arrow_selector);
			break;

		case IMG_CHECK:
			img.setVisibility(View.VISIBLE);
			img.setImageResource(R.drawable.check);
			break;

		default:
			img.setVisibility(View.GONE);
			break;
		}
	}

	public void constructList(boolean ListStyle) {
		m_list_controller.clear();
		for (int i = 0, l = m_items.size(); i < l; ++i) {
			View v = m_list_controller.m_layoutInflater.inflate(
					R.layout.skf_listcheck_item, null);
			updateView(v, i);
			m_list_controller.addView(v);
		}
		if (ListStyle) {
			m_list_controller.createList();
		} else {
			m_list_controller.createMenu();
		}
	}

	public int updateCaptions(String[] Captions) {
		int cnt = 0;
		int vl = m_list_controller.size();
		int il = m_items.size();
		int ic = Captions.length;
		for (int i = 0; i < ic; ++i) {
			if ((i >= vl) || (i >= il)) {
				break;
			}
			cnt++;
			m_items.get(i).caption = Captions[i];
			updateView(m_list_controller.getItem(i), i);
		}
		return cnt;
	}

	public int updateCaptions(List<String> Captions) {
		int cnt = 0;
		int vl = m_list_controller.size();
		int il = m_items.size();
		int ic = Captions.size();
		for (int i = 0; i < ic; ++i) {
			if ((i >= vl) || (i >= il)) {
				break;
			}
			cnt++;
			m_items.get(i).caption = Captions.get(i);
			updateView(m_list_controller.getItem(i), i);
		}
		return cnt;
	}

	public int updateItems() {
		int cnt = 0;
		int vl = m_list_controller.size();
		int il = m_items.size();
		for (int i = 0; i < il; ++i) {
			if (i >= vl) {
				break;
			}
			cnt++;
			updateView(m_list_controller.getItem(i), i);
		}
		return cnt;
	}

	public int size() {
		return m_items.size();
	}

	public SimpleItem getItem(int Index) {
		return m_items.get(Index);
	}

	public class SimpleItem {
		public String caption;
		boolean clickable;
		int imgType;

		public SimpleItem(String Caption, boolean Clickable, int ImgType) {
			this.caption = Caption;
			this.clickable = Clickable;
			this.imgType = ImgType;
		}

		public SimpleItem(String Caption, int ImgType) {
			this.caption = Caption;
			this.clickable = true;
			this.imgType = ImgType;
		}
	}
}
