package com.skf.vibracon.selection;
/*
superslon74@gmail.com
skype - superslon74
schamanskij gennadij aleksandrovich
*/

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.xmlpull.v1.XmlPullParser;

import com.skf.style.SKF_Listcheck_Activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Activity_SelectManually extends Activity implements
		OnClickListener {
	final String[] checkCatsName = { "PS", "SB" };
	// public String sys="PS";
	public String metricsys = "1";
	protected Button button11, button12, button13, button14;
	protected EditText edittext1, edittext2, edittext3, edittext4, edittext5,
			edittext6,boltp3,fitterbolts2;
	private DataHelper dh;
	protected TextView text2;
	private TextView textviev11, textviev12, textviev13, textviev16,
			textviev15, select_manual_text1, select_manual_text2,fitterbolts1;
	private TextView textviev1, textviev2, textviev3, textviev4, textviev5,
			textviev6;
	private Spinner spinner1, spinner2;
	private int flag, flag2;
	private String spinner1name;
	private String spinner1name2;
	private String button;
	int as1 = 0;
	String[] values;
	String[] textsA = { "Machine type" };// +selectmachinen
	String[] texts2A = { "not selected" };// +selectmachinen
	int bolttype1=0;
	//String bolttype2="1''";
	
	ListView lvMain;
	int mass2 = 1;
	String[] textsB = { "  Bolt hole pitch" };
	String[] texts2B = { "   PS" };
	SimpleAdapter sAdapter;

	public String selectmachinen = "not selected";
	public String selectmanufactorer = "not selected";
	public String model = "not selected";

	int ind = 0;
	int ind2 = 0;

	String[] concat(String[] A, String[] B) {
		String[] C = new String[A.length + B.length];
		System.arraycopy(A, 0, C, 0, A.length);
		System.arraycopy(B, 0, C, A.length, B.length);
		return C;
	}

	String[] spinnersvalues(int a) {
		if (a == 0) {
			List<String> nm = this.dh.selectAll21();
			int ns = nm.size();

			final String[] objects = new String[ns];// = names;

			int s = 0;
			for (String name : nm) {
				objects[s] = "M" + name;
				s++;
			}
			Set<String> set = new HashSet<String>(Arrays.asList(objects));
			String[] result2 = set.toArray(new String[set.size()]);

			int ssd = result2.length;
			final String[] result3 = new String[ssd];

			for (int j = 0; j < result2.length; j++) {

				for (int i = j + 1; i < result2.length; i++) {
					if (result2[i].compareTo(result2[j]) < 0) {
						String t = result2[j];
						result2[j] = result2[i];
						result2[i] = t;
					}
				}
				result3[j] = result2[j];
			}
			return result3;
		} else {
			List<String> nm = this.dh.selectAll211();
			int ns = nm.size();

			final String[] objects = new String[ns];// = names;

			int s = 0;
			for (String name : nm) {
				objects[s] = name + "''";

				s++;
			}
			Set<String> set = new HashSet<String>(Arrays.asList(objects));
			String[] result2 = set.toArray(new String[set.size()]);

			int ssd = result2.length;
			final String[] result3 = new String[ssd];

			for (int j = 0; j < result2.length; j++) {

				for (int i = j + 1; i < result2.length; i++) {
					if (result2[i].compareTo(result2[j]) < 0) {
						String t = result2[j];
						result2[j] = result2[i];
						result2[i] = t;
					}
				}
				result3[j] = result2[j];
			}
			return result3;
		}
	}

	public String konvert(String str) {
		String result = null;
		
		int not_error=(int)(Double.parseDouble(str));
		if(not_error<4){
	Hashtable<String, String> table = new Hashtable<String, String>();
		table.put("0.5", "12");
		table.put("0.5625", "14");
		table.put("0.625", "16");
		table.put("0.75", "20");
		table.put("1", "24");
		table.put("1.125", "30");
		table.put("1.25", "33");
		table.put("1.375", "36");
		table.put("0.75", "20");
		table.put("1", "24");
		table.put("1.25", "30");
		table.put("1.375", "36");
		table.put("1.5", "39");
		table.put("1.75", "45");
		table.put("2", "52");
		table.put("2.25", "56");
		table.put("2.5", "64");
		table.put("2.75", "68");
		result=table.get(str);
		return result;
		}
		else 
		{
			return str;
		}
}
	
	protected void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_selectmanually);
		((TableRow) findViewById(R.id.select_manual)).setOnClickListener(this);
		select_manual_text1 = (TextView) this
				.findViewById(R.id.select_manual_text1);
		select_manual_text2 = (TextView) this
				.findViewById(R.id.select_manual_text2);
		textviev1 = (TextView) this.findViewById(R.id.textviev1);
		textviev2 = (TextView) this.findViewById(R.id.textviev2);
		textviev3 = (TextView) this.findViewById(R.id.textviev3);
		textviev4 = (TextView) this.findViewById(R.id.textviev4);
		textviev5 = (TextView) this.findViewById(R.id.textviev5);
		textviev6 = (TextView) this.findViewById(R.id.textviev6);
		textviev16 = (TextView) this.findViewById(R.id.textviev16);
		findViewById(R.id.textspinner).setOnClickListener(this);

		dh = getDataHelper();
		String language = dh.selectLanguage();
		String[] names = { LanguageTools.machine_type,
				LanguageTools.dry_weight, LanguageTools.nominal_power,
				LanguageTools.nominal_speed,
				LanguageTools.number_of_bolt_holes,
				LanguageTools.diameter_of_bolt_hole, LanguageTools.select_bolt,
				LanguageTools.save, LanguageTools.calculate,LanguageTools.fitterbolts // enter_characteristics
		};

		values = LanguageTools.getStrings(this, language, names, 1);
		select_manual_text1.setText(values[0]);
		textviev1.setText(values[1]);
		textviev2.setText(values[2]);
		textviev3.setText(values[3]);
		textviev4.setText(values[4]);
		textviev5.setText(values[5]);
		textviev6.setText(values[6]);
		fitterbolts1= (TextView) this.findViewById(R.id.fitterbolts1);
		fitterbolts1.setText(values[9]);

		button = values[8];// parser.getAttributeValue(7);
		textsA[0] = "sss";// +parser.getAttributeValue(27);
		((TextView) findViewById(R.id.manualli_caption)).setText(values[8]);

		Intent intent = getIntent();
		selectmachinen = intent.getStringExtra("selectmachinen");
		selectmanufactorer = intent.getStringExtra("selectmanufactorer");
		model = intent.getStringExtra("model");
		if (selectmachinen == null)
			selectmachinen = "Generator";
		texts2A[0] = "" + selectmachinen;
		select_manual_text2.setText(texts2A[0]);

		flag2 = 1;

		edittext1 = (EditText) this.findViewById(R.id.edittext1);
		edittext2 = (EditText) this.findViewById(R.id.edittext2);
		edittext3 = (EditText) this.findViewById(R.id.edittext3);
		edittext4 = (EditText) this.findViewById(R.id.edittext4);
		edittext5 = (EditText) this.findViewById(R.id.edittext5);
		boltp3 = (EditText) this.findViewById(R.id.boltp3);
		fitterbolts2= (EditText) this.findViewById(R.id.fitterbolts2);
		
		textviev11 = (TextView) this.findViewById(R.id.textviev11);
		textviev12 = (TextView) this.findViewById(R.id.textviev12);
		textviev13 = (TextView) this.findViewById(R.id.textviev13);

		dh = getDataHelper();
		String names2 = this.dh.selectAll20();
		int mass = (int) (Integer.parseInt(names2.replaceAll("[^0-9]", "")));
		if (mass == 0) {
			metricsys = "0";
			String spv[] = spinnersvalues(0);
			textviev16.setText(spv[0]);
		
			 spinner1name2=removeCharAt(spv[0],0);
		} else {
			metricsys = "1";
			
			String spv[] = spinnersvalues(1);
			textviev16.setText(spv[0]);
	
			  String str2 =spv[0].substring(0,spv[0].length()-1);
			  String str3 = str2.substring(0,str2.length()-1);
			  
			  spinner1name2=str3; //
			}

		textviev16 = (TextView) this.findViewById(R.id.textviev16);
		textviev15 = (TextView) this.findViewById(R.id.textviev15);

		button13 = (Button) this.findViewById(R.id.button3);
		button13.setOnClickListener(this);
		button13.setText(button);
		dh = getDataHelper();
		String names22 = this.dh.selectAll20();
		mass2 = (int) (Integer.parseInt(names2.replaceAll("[^0-9]", "")));
		if (mass2 == 1) {
			textviev11.setText("lb");
			textviev12.setText("H.P");
			textviev15.setText("inch");
			//boltp2
			if (selectmachinen.equals("not selected")
					|| selectmanufactorer.equals("not selected")
					|| model.equals("not selected")) {
			} else {
				String names3 = this.dh.selectAll41(selectmachinen,
						selectmanufactorer, model);
			 // Toast.makeText(getApplicationContext(),
				//				names3, Toast.LENGTH_SHORT).show();

				String[] ss = names3.split("\\|");
				int ss1 = (int) (Integer.parseInt(ss[0]) * 0.45359);
				int ss2 = (int) (Integer.parseInt(ss[2]) * 0.74569);
				double ss3 = (double) (Integer.parseInt(ss[4]) * 0.03937);
     			String ss40=konvert(ss[5]); 
				double ss4 = (double) (Integer.parseInt(ss40));// * 0.03937);
				double ss5 = (Double.parseDouble(ss40)* 0.03937);
				
				edittext1.setText("" + ss1);
				edittext2.setText(ss[1]);
				edittext3.setText("" + ss2);
				edittext4.setText(ss[3]);
				// edittext5.setText(""+ss3);
				String names222 = this.dh.selectAllimp("" + ss3);
				String names333 = this.dh.selectAllimp2(names222);

				edittext5.setText(names333);
			//	boltp3.setText(""+ss5);
				String names444 = this.dh.selectAllimp("" + ss5);
				String names555 = this.dh.selectAllimp2(names444);
				// edittext5.setText(names555);
				boltp3.setText(""+ss5);
		 	
			}
		} else {

			if (selectmachinen.equals("not selected")
					|| selectmanufactorer.equals("not selected")
					|| model.equals("not selected")) {
			} else {
				String names3 = this.dh.selectAll41(selectmachinen,
						selectmanufactorer, model);
				//  Toast.makeText(getApplicationContext(),
				//			names3, Toast.LENGTH_SHORT).show();
			
				String[] ss = names3.split("\\|");
				edittext1.setText(ss[0]);
				edittext2.setText(ss[1]);
				edittext3.setText(ss[2]);
				edittext4.setText(ss[3]);
				edittext5.setText(ss[4]);
				// .setText("M"+ss[5]);
				String ss40=konvert(ss[5]);
				
				boltp3.setText(""+ss40);
				
				List<String> nm = this.dh.selectAll21();
				int ns = nm.size();

				final String[] objects = new String[ns];// = names;

				int s = 0;
				for (String name : nm) {
					objects[s] = name;
					s++;
				}
				Set<String> set = new HashSet<String>(Arrays.asList(objects));
				String[] result2 = set.toArray(new String[set.size()]);

				int ssd = result2.length;
				final String[] result3 = new String[ssd];

				for (int j = 0; j < result2.length; j++) {

					for (int i = j + 1; i < result2.length; i++) {
						if (result2[i].compareTo(result2[j]) < 0) {
							String t = result2[j];
							result2[j] = result2[i];
							result2[i] = t;
						}
					}
					result3[j] = result2[j];
				}

				for (int i = 0; i < result3.length; i++) {
					if (result3[i].equals(ss[5]))
						ind = i;

				}
				// spinner2.setSelection(ind);

			}
		}

	}

	public DataHelper getDataHelper() {
		return new DataHelper(this);
	}

	public String[] selectmachinen() {
		List<String> names2 = this.dh.selectAll3();
		int ns = names2.size();

		final String[] objects = new String[ns];// = names;

		int s = 0;
		for (String name : names2) {
			objects[s] = name;
			s++;
		}
		// objects[ns]="not selected";
		String[] a = new String[1];
		a[0] = "not selected";

		Set<String> set = new HashSet<String>(Arrays.asList(objects));
		String[] result2 = set.toArray(new String[set.size()]);
		int ssd = result2.length;
		final String[] result = new String[ssd];

		for (int j = 0; j < result2.length; j++) {

			for (int i = j + 1; i < result2.length; i++) {
				if (result2[i].compareTo(result2[j]) < 0) {
					String t = result2[j];
					result2[j] = result2[i];
					result2[i] = t;
				}
			}
			result[j] = result2[j];

		}

		return result;
	}

	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.textspinner: {
			
			  dh = getDataHelper(); String names2 = this.dh.selectAll20(); 
			  
			  int
			  mass=(int)(Integer.parseInt(names2.replaceAll("[^0-9]", "")));
			  if(mass==0) { 
				//  Toast.makeText(getApplicationContext(),
			//				"1111111111111", Toast.LENGTH_SHORT).show();

				  String[] spv=spinnersvalues(0); Intent I = new
			  Intent(this, SKF_Listcheck_Activity.class);
			  
			  I.putExtra(SKF_Listcheck_Activity.skf_Caption,values[6]);
			  I.putExtra(SKF_Listcheck_Activity.skf_Items,spv);
			  I.putExtra(SKF_Listcheck_Activity.skf_Selected,bolttype1);
			  startActivityForResult(I, 2);
			  } else { 
			//	  Toast.makeText(getApplicationContext(),
				//			"22222222", Toast.LENGTH_SHORT).show();

					
				  String[] spv=spinnersvalues(1); Intent I = new Intent(this,
			  SKF_Listcheck_Activity.class);
			  
			  I.putExtra(SKF_Listcheck_Activity.skf_Caption,values[6]);
			  I.putExtra(SKF_Listcheck_Activity.skf_Items,spv);
			  I.putExtra(SKF_Listcheck_Activity.skf_Selected, -1);
			  startActivityForResult(I, 2);
			  
			  }
			  
			     break;}
		case R.id.select_manual: {

			String[] a = new String[1];
			a[0] = "not selected";
			int as2=0;
			final String[] result21 = concat(a, selectmachinen());
			int dlina=result21.length;
			for(int i=0;i<dlina;i++)
			{
				if(result21[i].equals(selectmachinen))
				{
					as2=i;
				}
			}
		/*		
			Toast.makeText(getApplicationContext(),selectmachinen+
					" "+result21[2], Toast.LENGTH_SHORT).show();
*/
			
			Intent I = new Intent(this, SKF_Listcheck_Activity.class);

			I.putExtra(SKF_Listcheck_Activity.skf_Caption, values[0]);
			I.putExtra(SKF_Listcheck_Activity.skf_Items, result21);
			I.putExtra(SKF_Listcheck_Activity.skf_Selected, as2);
			startActivityForResult(I, 1);
			
			break;
		}
		default: {

			break;
		}
		}
		if (v == button13) {
			if (selectmachinen == "not selected") {
				Toast.makeText(getApplicationContext(),
						"Not selected machinen", Toast.LENGTH_SHORT).show();

			} else {
				String str1 = edittext5.getText().toString();
				String str3 = edittext1.getText().toString();
				String str4 = edittext2.getText().toString();
				String str5 = edittext3.getText().toString();
				String str6 = edittext4.getText().toString();
				String str7 = boltp3.getText().toString();
				int flag = 0;
				int dlina1 = str1.length();
				int dlina3 = str3.length();
				int dlina4 = str4.length();
				int dlina5 = str5.length();
				int dlina6 = str6.length();
				int dlina7 = str7.length();
				
				if (dlina3 < 1) {
					Toast.makeText(getApplicationContext(), "enter Dry weight",
							Toast.LENGTH_SHORT).show();
					flag = 1;
				} else if (dlina4 < 1) {
					Toast.makeText(getApplicationContext(),
							"enter Nominal Power", Toast.LENGTH_SHORT).show();
					flag = 1;
				} else if (dlina5 < 1) {
					Toast.makeText(getApplicationContext(),
							"enter Nominal Speed", Toast.LENGTH_SHORT).show();
					flag = 1;
				} else if (dlina6 < 1) {

					Toast.makeText(getApplicationContext(),
							"enter Number of bolt holes", Toast.LENGTH_SHORT)
							.show();
					flag = 1;
				}

				else if(dlina7<1)
				{
						Toast.makeText(getApplicationContext(),
							"Enter step bolt pitch", Toast.LENGTH_SHORT)
							.show();
					flag = 1;
				
				//konvert2(String str)
						
					
				}
				
				else if (dlina1 < 1 || dlina1>1) {
//*******************************************************
				//	flag=0;
					if (dlina1 < 1){
				//	if (mass2 == 0) {
						Toast.makeText(getApplicationContext(),
								"enter Diameter of bolt", Toast.LENGTH_SHORT)
								.show();
						flag = 1;
				}
				//	} else {
					//	flag = 1;
				
				if (dlina1>1)
				{
					if (mass2 == 1) {
					//		String str=
					boolean res=konvert2(edittext5.getText().toString());
							if(res==true){
								/*
								Toast.makeText(getApplicationContext(),
										"!!!!!!!!!!!!!", Toast.LENGTH_SHORT)
										.show();
								*/
								flag=0;
							}

							else
							{
								
								Toast.makeText(getApplicationContext(),
										"malformed input, for example: 1-1/2", Toast.LENGTH_SHORT)
										.show();
								flag=1;
							}
				
				}	
									}

				} else {
					int masss = (int) (Integer.parseInt(str6));
					if (masss < 1) {
						Toast.makeText(getApplicationContext(),
								"Number of bolt holes can not be less than 1",
								Toast.LENGTH_SHORT).show();

						flag = 1;
					} else {
						flag = 0;
					}

				//	konvert2(String str)
					
				}

			
				
				if (flag == 0) {
				//	Toast.makeText(getApplicationContext(),
					//		"00000!!!!!!!!!!!!", Toast.LENGTH_SHORT).show();
			
						String str2=spinner1name2;//textviev16.setText(spv[as2]);
					int st1 = Integer.parseInt(str1.replaceAll("[^0-9]", ""));
					int st2 = Integer.parseInt(str2.replaceAll("[^0-9]", ""));
					if (metricsys.equals("0")) {
				
						
			if ((st1 + 1) > (st2)) {
							
	/*					      Toast.makeText(
							  getApplicationContext(),selectmachinen+","+
							  edittext1.getText().toString()+","+
							  edittext2.getText().toString()+","+
							  edittext3.getText().toString()+","+
							  edittext4.getText().toString()+","+
							  edittext5.getText().toString()+","+
							  spinner1name2+","+ metricsys,
							  Toast.LENGTH_SHORT).show();
*/

							Intent intent = new Intent(this,
									Activity_SelectVibracon2.class);
							intent.putExtra("selectmachinen", selectmachinen);
							intent.putExtra("waight", edittext1.getText()
									.toString());
							intent.putExtra("power", edittext2.getText()
									.toString());
							intent.putExtra("speed", edittext3.getText()
									.toString());
							intent.putExtra("number", edittext4.getText()
									.toString());
							intent.putExtra("diameterbolt", edittext5.getText()
									.toString());
							intent.putExtra("defaultbolt", spinner1name2);
							intent.putExtra("metricsys", metricsys);
							intent.putExtra("boltpish", boltp3.getText()
									.toString());
							intent.putExtra("fitterbolts2",fitterbolts2.getText()
									.toString());
							
							// startActivity(intent);
							startActivityForResult(intent, 22);
					// finish();

						} else {
							Toast.makeText(getApplicationContext(),
									"diameter of bolt home less select bolt",
									Toast.LENGTH_SHORT).show();
						}

						// int mass=(int)(Integer.parseInt(str6));

					} else {
				/*		  Toast.makeText(
						  getApplicationContext(),selectmachinen+","+
						  edittext1.getText().toString()+","+
						  edittext2.getText().toString()+","+
						  edittext3.getText().toString()+","+
						  edittext4.getText().toString()+","+
						  edittext5.getText().toString()+","+
						  spinner1name2+","+ metricsys,
						  Toast.LENGTH_SHORT).show();
	*/
						Intent intent = new Intent(this,
								Activity_SelectVibracon2.class);
						intent.putExtra("selectmachinen", selectmachinen);
						intent.putExtra("waight", edittext1.getText()
								.toString());
						intent.putExtra("power", edittext2.getText().toString());
						intent.putExtra("speed", edittext3.getText().toString());
						intent.putExtra("number", edittext4.getText()
								.toString());
						intent.putExtra("diameterbolt", edittext5.getText()
								.toString());
						intent.putExtra("defaultbolt", spinner1name2);
						intent.putExtra("metricsys", metricsys);
						intent.putExtra("boltpish", boltp3.getText()
								.toString());
						intent.putExtra("fitterbolts2",fitterbolts2.getText()
								.toString());
					
						// startActivity(intent);
						startActivityForResult(intent, 23);
						// finish();

					}
				}
				flag = 0;
			}
		}

	}

	public boolean konvert2(String str) {
		ArrayList arrayList = new ArrayList();
		arrayList.add("1/2");
		arrayList.add("9/16");
		arrayList.add("5/8");
		arrayList.add("3/4");
		arrayList.add("7/8");
		arrayList.add("1");
		arrayList.add("1-1/8");
		arrayList.add("1-1/4");
		arrayList.add("1-3/8");
		arrayList.add("1-1/2");
		arrayList.add("1-3/4");
		arrayList.add("2");
		arrayList.add("2-1/4");
		arrayList.add("2-1/2");
		arrayList.add("2-3/4");
		boolean blnFound = arrayList.contains(str);
		return blnFound;
}	

	
	
	
	
	
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// Check which request we're responding to
		if (requestCode == 1) {
			if (resultCode == RESULT_OK) {
				// selectmachinen = data.getStringExtra("selectmachinen");
				// texts2A[0] =""+selectmachinen;
				// texts2B[0] ="   "+sys;
				// flag2=1;
				// select_manual_text2.setText(texts2A[0]);

				// ----------------------
				as1 = data.getIntExtra(SKF_Listcheck_Activity.skf_Selected, -1);

				texts2A[0] = selectmachinen;
				// Toast.makeText(this,"languages", Toast.LENGTH_SHORT).show();

				String[] a = new String[1];
				a[0] = "not selected";
				final String[] result22 = concat(a, selectmachinen());

				selectmachinen = result22[as1];// data.getStringExtra("selectmachinen");
				texts2A[0] = "" + selectmachinen;
				select_manual_text2.setText(texts2A[0]);

			}
		}

		if (requestCode == 22) {
			if (resultCode == RESULT_OK) {
				Intent I=new Intent();
				setResult(RESULT_OK,I);
			finish();
				
			}
		}
		
		if (requestCode == 23) {
			if (resultCode == RESULT_OK) {
				Intent I=new Intent();
				setResult(RESULT_OK,I);
			finish();
				
			}
		}
		
		if (requestCode == 2) {
			if (resultCode == RESULT_OK) {
			int	as2 = data.getIntExtra(SKF_Listcheck_Activity.skf_Selected, -1);
			dh = getDataHelper();
			if (metricsys.equals("0")) {
				String spv[] = spinnersvalues(0);
				textviev16.setText(spv[as2]);
				bolttype1=as2;
				 spinner1name2=spv[as2];
			} else
			{
				String spv[] = spinnersvalues(1);
				textviev16.setText(spv[as2]);
				bolttype1=as2;
				  String str2 =spv[as2].substring(0,spv[as2].length()-1);
				  String str3 = str2.substring(0,str2.length()-1);
				  
				  spinner1name2=str3; //
				
								
				
			}
				
				
			}
		}

	}

	public static String removeCharAt(String s, int pos) {

		return s.substring(0, pos) + s.substring(pos + 1);

	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}

}  