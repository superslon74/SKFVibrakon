package com.skf.vibracon.selection;

/*
 superslon74@gmail.com
 skype - superslon74
 schamanskij gennadij aleksandrovich
 */

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.xmlpull.v1.XmlPullParser;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.skf.vibracon.selection.DataHelper;

public class Activity_Vibracon extends Activity implements OnClickListener {

	private DataHelper dh;
	public TextView city_text1, adress_text1, phone_text, web_text, email_text,
			map_text;
	String info = null;
	String[] res = null;
	String[] values = null;

	protected void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_vibracon);
		dh = getDataHelper();
		String language = dh.selectLanguage();
		String[] names = { LanguageTools.select_vibracon,
				LanguageTools.calculate, LanguageTools.choice_of_base,LanguageTools.enter_characteristics};
		values = LanguageTools.getStrings(this, language, names, 1);
		((TextView) findViewById(R.id.vibracons)).setText(values[0]);
		((TextView) findViewById(R.id.calculate_text)).setText(values[1]);
		((TextView) findViewById(R.id.mannually_text)).setText(values[3]);
		((TextView) findViewById(R.id.select_text)).setText(values[2]);
		findViewById(R.id.calculate).setOnClickListener(this);
		findViewById(R.id.mannually).setOnClickListener(this);
		findViewById(R.id.select).setOnClickListener(this);
	
	}

	public DataHelper getDataHelper() {
		return new DataHelper(this);
	}

	public void onClick(View v) {
		switch (v.getId()) {
		
		case R.id.mannually: {
			Intent intent2 = new Intent(getApplicationContext(),
					Activity_SelectManually.class);

			intent2.putExtra("selectmachinen","not selected");
			intent2.putExtra("selectmanufactorer","not selected");
			intent2.putExtra("model","not selected");
			startActivityForResult(intent2,3);
			

			break;
		}
		case R.id.calculate: {
			startActivityForResult(new Intent(this, Activity_Calculate.class),
					1);

			break;
		}
		case R.id.select: {
					String[] str = { "1" };
			Intent I = new Intent(this, SKF_Listcheck4_Activity.class);

			I.putExtra(SKF_Listcheck4_Activity.skf_Caption, values[2]);
			I.putExtra(SKF_Listcheck4_Activity.skf_Items, str);
			I.putExtra("number", "12");

			I.putExtra(SKF_Listcheck4_Activity.skf_Selected, -1);

			startActivityForResult(I, 2);
		
			break;
		}

		}
		
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// Check which request we're responding to
		if (requestCode == 2) {
			if (resultCode == RESULT_OK) {
				Intent intent = getIntent();

				String select = intent.getStringExtra("selectext");

				finish();

										}
								}
		else if (requestCode == 1) {
			if (resultCode == RESULT_OK) {
					finish();

										}
								}
		
	}

}