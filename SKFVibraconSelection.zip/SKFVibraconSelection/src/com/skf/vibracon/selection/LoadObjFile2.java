package com.skf.vibracon.selection;

import android.widget.Toast;
import min3d.core.Object3dContainer;
import min3d.core.RendererActivity;
import min3d.parser.IParser;
import min3d.parser.Parser;
import min3d.vos.Light;

import android.view.MotionEvent;


public class LoadObjFile2 extends RendererActivity {
	private Object3dContainer objModel,objModel2;
	  boolean rotating = false;
      int prevSwipeY, swipeY;
      int prevSwipeX, swipeX;
      int prevSwipeZ, swipeZ;
      final int ROTATION_SPEED = 2;
      
      int upPI = 0;
      int downPI = 0;
      boolean inTouch = false;
      
	@Override
	public void initScene() {

		scene.lights().add(new Light());

		IParser parser = Parser.createParser(Parser.Type.OBJ, getResources(),
				"com.skf.vibracon.selection:raw/camaro2_obj", true);
		parser.parse();

		objModel = parser.getParsedObject();
		objModel2=objModel;
		objModel.scale().x = objModel.scale().y = objModel.scale().z = .7f;
		scene.addChild(objModel);
				
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
	/*    switch (event.getAction()) {
	   	    
	    case MotionEvent.ACTION_POINTER_DOWN:
	    	  rotating = true;
		      prevSwipeY = swipeY = 0; // for the Y axis
		        prevSwipeX = swipeX = 0; // for the X axis
		        objModel.rotation().y =0;
		        objModel.rotation().x =0;
	    	
	        break;
	    case MotionEvent.ACTION_UP:
	       	break;
	    case MotionEvent.ACTION_MOVE:
	        float directionY = (prevSwipeY - event.getX()) * -1;
	        float directionX = (prevSwipeX - event.getY()) * -1;
	        swipeY = (int) (directionY * ROTATION_SPEED);
	        swipeX = (int) (directionX * ROTATION_SPEED);
	         break;
	        
	    case MotionEvent.ACTION_DOWN: //������ �������
	          break;       
	        
	    }
*/
	    int actionMask = event.getActionMasked();
	    // ������ �������
	    int pointerIndex = event.getActionIndex();
	    // ����� �������
	    int pointerCount = event.getPointerCount();

	    switch (actionMask) {
	    case MotionEvent.ACTION_DOWN: // ������ �������
	      inTouch = true;
	    case MotionEvent.ACTION_POINTER_DOWN: // ����������� �������
	  
	    	if (pointerCount>1) { 	
	    	downPI = pointerIndex;
	      prevSwipeY = swipeY = 0; // for the Y axis
	        prevSwipeX = swipeX = 0; // for the X axis
	        objModel.rotation().y =0;
	        objModel.rotation().x =0;
	    	}
	      break;

	    case MotionEvent.ACTION_UP: // ���������� ���������� �������
	      inTouch = false;
	    
	    case MotionEvent.ACTION_POINTER_UP: // ���������� �������
	      upPI = pointerIndex;
	      break;

	    case MotionEvent.ACTION_MOVE: // ��������
	    	  float directionY = (prevSwipeY - event.getX()) * -1;
		        float directionX = (prevSwipeX - event.getY()) * -1;
		        swipeY = (int) (directionY * ROTATION_SPEED);
		        swipeX = (int) (directionX * ROTATION_SPEED);
		         break;
	    
	    }  
	    
	    
	    // Camera pivot point is different 
	   prevSwipeY = (int) event.getX();
	    prevSwipeX = (int) event.getY();
	    return super.onTouchEvent(event);
	}	
	
	
	
	
	
	
	@Override
	public void updateScene() {
		 if (objModel != null) {  // If an object is loaded
		        if (swipeY != 0)  // and we did swiped in the correct direction
		            objModel.rotation().y += swipeY;

		        swipeY = 0; // Reset the pointer

		        if (swipeX != 0)  // and we did swiped in the correct direction
		            objModel.rotation().x += swipeX;

		        swipeX = 0; // Reset the pointer
		        
		        try {
		            Thread.sleep(55);
		        } catch (Exception e) {

		        }
		 }
	}
}
