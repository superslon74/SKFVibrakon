package com.skf.vibracon.selection;
/*
superslon74@gmail.com
skype - superslon74
schamanskij gennadij aleksandrovich
*/

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.xmlpull.v1.XmlPullParser;
import android.widget.TableRow;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import com.skf.style.*;

public class Activity_Calculate extends Activity implements OnClickListener {
	protected Button button11111, button11, button12, button13, button14, button15;
	private DataHelper dh;
	public String selectmachinen = "not selected";
	public String selectmanufactorer = "not selected";
	public String model = "not selected";
	public String save_model = "";
	public String[] texts = {"Machine type" };
	public String[] texts2 = {"Generator" };
	public String[] textsA = {"Manufacturer" };
	public String[] texts2A = {"General Electric" };
	public String[] textsB = {"Model" };
	public String[] texts2B = {"not selected" };
	public String[] textsD = {"Enter charecteristics manually" };
	String[] values=null;
	TextView mm_i1_text1,mm_i1_text2,mm_i2_text1,mm_i2_text2,mm_i3_text1,mm_i3_text2,mm_i4_text1,mm_i4_text2;
	private final static int requestList =1;
	private final static int requestList2 =2;
	private final static int requestList3 =3;
	private final static int requestList4 =4;
	private final static int requestList5 =5;
					;

	int SELECT_ITEM = 1;
	int as1=0;
	int as2=0;
	int as3=0;
	String[] concat(String[] A, String[] B){
		String[] C= new String[A.length+B.length]; 
		System.arraycopy(A, 0, C, 0, A.length); 
		System.arraycopy(B, 0, C, A.length, B.length); 
		return C;
		                                  } 	
	
	
	protected void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_calculate);
		TableLayout table = (TableLayout)findViewById(R.id.mm);
		//TableRow sity=(TableRow)findViewById(R.id.sity);
		
	/*	((TableRow) findViewById(R.id.mm_i1)).setOnClickListener(this);
	     ((TableRow) findViewById(R.id.mm_i2)).setOnClickListener(this);
	     ((TableRow) findViewById(R.id.mm_i3)).setOnClickListener(this);
	     ((TableRow) findViewById(R.id.mm_i4)).setOnClickListener(this);
	  */   
		TableRow mm_i1=(TableRow)findViewById(R.id.mm_i1);
		mm_i1.setOnClickListener(this);
		TableRow mm_i2=(TableRow)findViewById(R.id.mm_i2);
		mm_i2.setOnClickListener(this);
		TableRow mm_i3=(TableRow)findViewById(R.id.mm_i3);
		mm_i3.setOnClickListener(this);
		TableRow mm_i4=(TableRow)findViewById(R.id.mm_i4);
		mm_i4.setOnClickListener(this);
	
		        mm_i2_text1 = (TextView) findViewById(R.id.mm_i2_text1); 
		 	mm_i2_text2 = (TextView) findViewById(R.id.mm_i2_text2); 
			mm_i1_text1 = (TextView) findViewById(R.id.mm_i1_text1); 
			mm_i1_text2 = (TextView) findViewById(R.id.mm_i1_text2);
			mm_i3_text1 = (TextView) findViewById(R.id.mm_i3_text1); 	  
			mm_i3_text2 = (TextView) findViewById(R.id.mm_i3_text2);
			mm_i4_text1 = (TextView) findViewById(R.id.mm_i4_text1); 	  
			
	     
	     
		dh = getDataHelper();
		 String language=dh.selectLanguage();
		    String[] names = { LanguageTools.machine_type,
		    		LanguageTools.manufacturer,LanguageTools.model,LanguageTools.enter_characteristics,
		    		LanguageTools.save_vibracon,
		    		LanguageTools.calculate};
			 values = LanguageTools.getStrings(this, language, names,1);
		
			 texts[0] =values[0];
		     textsA[0] =values[1];
		     textsB[0] =values[2];
		     textsD[0] =values[3];  
		     save_model=values[4]; 
		     ((TextView) findViewById(R.id.calcucate_vibracons))
		 	.setText(values[5]);
	  	texts2[0] = ""+ selectmachinen;
		texts2A[0] = ""+selectmanufactorer;
		texts2B[0] = ""+ model;

		 mm_i1_text1.setText(texts[0]);
		 mm_i1_text2.setText(texts2[0]);
		  
		 mm_i2_text1.setText(textsA[0]);
		 mm_i2_text2.setText(texts2A[0]);

		 mm_i3_text1.setText(textsB[0]);
		 mm_i3_text2.setText(texts2B[0]);
	
		 mm_i4_text1.setText(textsD[0]);
		 
		
		
		button11111 = (Button) this.findViewById(R.id.button11111);
		button11111.setOnClickListener(this);
		button11111.setText(save_model);
   	
		table.removeView(mm_i4);
	//	table.removeView(email);
		mm_i3.setBackgroundResource(R.drawable.skf_menu_item_bottom);
		mm_i3.setPadding(25, 25, 25, 25);      
			
		
	}

	public DataHelper getDataHelper() {
		return new DataHelper(this);
	}

	public String[] selectmodel(String selectmachinen,String selectmanufactorer)
	{
		List<String> names2 = this.dh.selectAll5(selectmachinen,selectmanufactorer);
		   //  StringBuilder sb = new StringBuilder();
		   //  sb.append("������ � ��:\n");
		     int ns=names2.size();
		 
		    final String[] objects=new String[ns];// = names;
		    
		   int s=0;
		     for (String name : names2) {
		    	 objects[s]=name;
		    	 s++;
		    }
		     String[] a=new String[1];
		     a[0]="not selected";
		   
		     
		     Set<String> set = new HashSet<String>(Arrays.asList(objects));
		     final String[] result2 = set.toArray(new String[set.size()]);    
		     int ssd=result2.length; 
		     final String[] result=new String[ssd];
		    
		    for (int j = 0; j < result2.length; j++) {
		   	 
		   
		        for (int i = j + 1; i < result2.length; i++) { 
		             if (result2[i].compareTo(result2[j]) < 0) { 
		                 String t = result2[j];
		                 result2[j] = result2[i];
		                 result2[i] = t;
		             } 
		        }  
		        result[j]=result2[j];
		        
		    }	
		
		return result;
		
	}
	
	
	public String[] selectmanufactor(String selectmachinen)
	{
		 List<String> names2 = this.dh.selectAll4(selectmachinen);
		   //  StringBuilder sb = new StringBuilder();
		   //  sb.append("������ � ��:\n");
		     int ns=names2.size();
		 
		    final String[] objects=new String[ns];// = names;
		    
		   int s=0;
		     for (String name : names2) {
		    	 objects[s]=name;
		    	 s++;
		    }
		     
		     String[] a=new String[1];
		     a[0]="not selected";
		     
		   
		     
		     Set<String> set = new HashSet<String>(Arrays.asList(objects));
		     final String[] result2 = set.toArray(new String[set.size()]);
		     int ssd=result2.length; 
		     final String[] result=new String[ssd];
		    
		    for (int j = 0; j < result2.length; j++) {
		   	 
		   
		        for (int i = j + 1; i < result2.length; i++) { 
		             if (result2[i].compareTo(result2[j]) < 0) { 
		                 String t = result2[j];
		                 result2[j] = result2[i];
		                 result2[i] = t;
		             } 
		        }  
		        result[j]=result2[j];
		        
		    }
	    return result;
	}
	
	public String[] selectmachinen()
	{
		 List<String> names2 = this.dh.selectAll3();
	     int ns=names2.size();
	     
	    final String[] objects=new String[ns];// = names;
	   
	   int s=0;
	     for (String name : names2) {
	    	 objects[s]=name;
	    	 s++;
	    }
	    // objects[ns]="not selected";
	    String[] a=new String[1];
	     a[0]="not selected";
	     
	     
	     Set<String> set = new HashSet<String>(Arrays.asList(objects));
	      String[] result2 = set.toArray(new String[set.size()]);
	      int ssd=result2.length; 
	      final String[] result=new String[ssd];
	     
	        
	     for (int j = 0; j < result2.length; j++) {
	    	 
	    
	         for (int i = j + 1; i < result2.length; i++) { 
	              if (result2[i].compareTo(result2[j]) < 0) { 
	                  String t = result2[j];
	                  result2[j] = result2[i];
	                  result2[i] = t;
	              } 
	         }  
	         result[j]=result2[j];
	  
	     }
	    
	     return result;
	}
	
	public void onClick(View v) {
	switch (v.getId()) {
		case R.id.mm_i1: {
			
			  String[] a=new String[1];
			     a[0]="not selected";
			   final  String[] result21=concat(a,selectmachinen());
			Intent I = new Intent(this, SKF_Listcheck_Activity.class);

			I.putExtra(SKF_Listcheck_Activity.skf_Caption, values[0]);
			I.putExtra(SKF_Listcheck_Activity.skf_Items,result21);
			I.putExtra(SKF_Listcheck_Activity.skf_Selected, as1);
			startActivityForResult(I, requestList);
	break;
		}
		case R.id.mm_i2: {
			if (selectmachinen.equals("not selected")){
				Toast.makeText(getApplicationContext(),
						"select machine type first", Toast.LENGTH_SHORT)
						.show();
				
			} else {
				  String[] a=new String[1];
				     a[0]="not selected";
				   final  String[] result21=concat(a,selectmanufactor(selectmachinen));
				Intent I = new Intent(this, SKF_Listcheck_Activity.class);

				I.putExtra(SKF_Listcheck_Activity.skf_Caption,values[1]);
				I.putExtra(SKF_Listcheck_Activity.skf_Items,result21);
				I.putExtra(SKF_Listcheck_Activity.skf_Selected, as2);
				startActivityForResult(I, requestList2);
			
					
			}
			break;
			
		}
		case R.id.mm_i3: {
			
			if (selectmachinen.equals("not selected")
					|| selectmanufactorer.equals("not selected")){
				Toast.makeText(getApplicationContext(),
						"select manufacturer first",
						Toast.LENGTH_SHORT).show();
			} else {		
	
				 String[] a=new String[1];
			     a[0]="not selected";
			   final  String[] result21=concat(a,selectmodel(selectmachinen,selectmanufactorer));
			Intent I = new Intent(this, SKF_Listcheck_Activity.class);

			I.putExtra(SKF_Listcheck_Activity.skf_Caption,values[2]);
			I.putExtra(SKF_Listcheck_Activity.skf_Items,result21);
			I.putExtra(SKF_Listcheck_Activity.skf_Selected, as3);
			startActivityForResult(I, requestList3);
		
			}
			break;
			
		}
		
		case R.id.mm_i4: {
			Intent intent2 = new Intent(getApplicationContext(),
					Activity_SelectManually.class);

			intent2.putExtra("selectmachinen", selectmachinen);
			intent2.putExtra("selectmanufactorer", selectmanufactorer);
			intent2.putExtra("model", model);
			startActivityForResult(intent2,requestList4);
			
        	break;
			
		}
		
		case R.id.button11111: {
		
			if (selectmachinen.equals("not selected")
					|| selectmanufactorer.equals("not selected")
					|| model.equals("not selected")){
				Toast.makeText(getApplicationContext(),
						"select machinen or manufacturer or model first",
						Toast.LENGTH_SHORT).show();
			} else {

				Intent intent = new Intent(getApplicationContext(), Activity_SelectVibracon.class);
				intent.putExtra("selectmachinen", selectmachinen);
				intent.putExtra("selectmanufactorer", selectmanufactorer);
				intent.putExtra("model", model);
			startActivityForResult(intent,requestList5);
			//finish();
			}
		
			break;
			
		}
		
		default: {
			
			break;
		}
		
		}
		

		
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// Check which request we're responding to
		if (requestCode == requestList) {
			if (resultCode == RESULT_OK) {
				as1=data.getIntExtra(SKF_Listcheck_Activity.skf_Selected, -1);
				
				
				texts2[0] = selectmachinen;
				// Toast.makeText(this,"languages", Toast.LENGTH_SHORT).show();
				as2=0;
				as3=0;
				 String[] a=new String[1];
			     a[0]="not selected";
			   final  String[] result22=concat(a,selectmachinen());
				
				selectmachinen = result22[as1];//data.getStringExtra("selectmachinen");
				// oast.makeText(getApplicationContext(),
				// selectmachinen+" "+selectmachinen.length(),
				// Toast.LENGTH_LONG).show();
				if (texts2[0].equals(selectmachinen)) {
				} else {
					texts2[0] = "" + selectmachinen;
					
					// ������ ���� ���������, �� ������� ����� �������� ������
					texts2A[0] = "not selected";
					selectmanufactorer = texts2A[0];
					texts2B[0] = "not selected";
					model = texts2B[0];
				as2=0;as3=0;
					mm_i1_text2.setText(texts2[0]);
					  
				    mm_i2_text2.setText(texts2A[0]);
				
    				mm_i3_text2.setText(texts2B[0]);
				
				}

			}
		}

		else if (requestCode == requestList2) {
			if (resultCode == RESULT_OK) {
				texts2A[0] = selectmanufactorer;
				//selectmanufactorer = data.getStringExtra("selectmanufactorer");

               as2=data.getIntExtra(SKF_Listcheck_Activity.skf_Selected, -1);
               //as2=0;
				as3=0;
				
               String[] a=new String[1];
			     a[0]="not selected";
			   final  String[] result22=concat(a,selectmanufactor(selectmachinen));
				
				selectmanufactorer = result22[as2];//data.getStringExtra("selectmachinen");
	
				if (texts2A[0].equals(selectmanufactorer)) {
				} else {
						texts2A[0] = "" + selectmanufactorer;
					texts2B[0] = "not selected";
					model = texts2B[0];
					//	 mm_i2_text1.setText(textsA[0]);
						 mm_i2_text2.setText(texts2A[0]);
						 mm_i3_text2.setText(texts2B[0]);
							
						 }
		
			}
		} 
		
		else if (requestCode == requestList3) {
			if (resultCode == RESULT_OK) {
				texts2B[0] = model;
				
				//model = data.getStringExtra("model");
				
				 as3=data.getIntExtra(SKF_Listcheck_Activity.skf_Selected, -1);
					
	               String[] a=new String[1];
				     a[0]="not selected";
				   final  String[] result23=concat(a,selectmodel(selectmachinen,selectmanufactorer));
					
					model = result23[as3];//data.getStringExtra("selectmachinen");
		
				
				
				if (texts2B[0].equals(model)) {
				} else {

					texts2B[0] = "" + model;

					// mm_i3_text1.setText(textsB[0]);
					 mm_i3_text2.setText(texts2B[0]);
									
					
				}
			}

		}

		if (requestCode == 5) {
			if (resultCode == RESULT_OK) {
				Intent I=new Intent();
				setResult(RESULT_OK,I);
			finish();
				
			}
		} else if (requestCode == 4) {
			if (resultCode == RESULT_OK) {
				Intent I=new Intent();
				setResult(RESULT_OK,I);
			finish();
				
			}
		}

		else if (requestCode == 22) {

		//	finish();
		}

	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {  
	        super.onConfigurationChanged(newConfig);  
	}	

}