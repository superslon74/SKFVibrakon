package com.skf.vibracon.selection;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.os.Handler;
import android.view.Window;

public class Activity_Splash extends Activity {

	private DataHelper dh;
	boolean dbLoading;
	String[] tbl3, tbl4;

	int loadPosition = 0;

	ProgressBar pbDownload;
	final int STATUS_BASE = 0;
	final int STATUS_BASE1 = 1; // ���� �� ��������
	final int STATUS_BASE2 = 2; // �������� ������ ��������
	final int STATUS_BASE3 = 3; // ����� ���������
	final int STATUS_BASE4 = 4;// ������ �������� ���� ������
	final int STATUS_BASE5 = 5; // �������� ���� ���������
	final int STATUS_BASE6 = 6; // �������� ���� ���������
	final int STATUS_BASE7 = 7; // �������� ������ ��������
	final int STATUS_BASE8 = 8; // ����� ���������
	final int STATUS_BASE9 = 9;// ������ �������� ���� ������
	final int STATUS_BASE10 = 10; // �������� ���� ���������
	final int STATUS_BASE11 = 11; // �������� ���� ���������

	final Handler onLoad = new Handler() {
		public void handleMessage(android.os.Message msg) {
			pbDownload.setMax(tbl3.length + tbl4.length);
		}
	};
	
	final Handler ht3 = new Handler() {
		public void handleMessage(android.os.Message msg) {
			loadPosition++;
			pbDownload.setProgress(loadPosition);
		}
	};

	final Handler ht4 = new Handler() {
		public void handleMessage(android.os.Message msg) {
			loadPosition++;
			pbDownload.setProgress(loadPosition);
		}
	};

	@SuppressLint("HandlerLeak")
	final Handler onLoadComplete = new Handler() {
		public void handleMessage(android.os.Message msg) {
			goNext();

		}
	};

	String getStringFromRawFile() throws IOException {
		// "�������" �������
		// / Resources r = activity.getResources();
		// ������ -> ����� Inputstream

		InputStream inputStream = getResources().openRawResource(
				R.raw.scripsqldatabase);
		InputStreamReader inputreader = new InputStreamReader(inputStream);
		BufferedReader buffreader = new BufferedReader(inputreader);

		String line;

		String text = new String("");
		while ((line = buffreader.readLine()) != null) {

			text = text + line + "#";
		}
		return text;
	}

	String getStringFromRawFile2() throws IOException {
		// "�������" �������
		// Resources r = activity.getResources();
		// ������ -> ����� Inputstream

		InputStream inputStream = getResources().openRawResource(
				R.raw.scriptsqldatabase2);
		InputStreamReader inputreader = new InputStreamReader(inputStream);
		BufferedReader buffreader = new BufferedReader(inputreader);

		String line;

		String text = new String("");
		while ((line = buffreader.readLine()) != null) {

			text = text + line + "#";
		}
		return text;
	}

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);		
		setContentView(R.layout.activity_splash);
		dh = getDataHelper();


		@SuppressWarnings("deprecation")
		int width = getWindowManager().getDefaultDisplay().getWidth();

		final int bw = 640;
		final int bh = 800;
		final int i_vibracon_width = 490;
		final int i_vibracon_margin = (int) (width * (bw - i_vibracon_width)
				* 0.5 / bw);

		// int bh2 = (int) (bh * 0.2);
		//
		// int bh3 = bh - height;
		// int bh4 = (int) ((bh2 - bh3));

		ImageView A = (ImageView) this.findViewById(R.id.skf);
		// A.getLayoutParams().height =height-bh2-bh3-bh4;
		// A.getLayoutParams().height = height - 200;
		A.getLayoutParams().height = (int) ((width * bh) / bw);

		pbDownload = (ProgressBar) findViewById(R.id.pbDownload);
		LinearLayout pbLinearLayout = (LinearLayout) findViewById(R.id.pbLayout);

		pbLinearLayout.setPadding(i_vibracon_margin, 0, i_vibracon_margin, 0);

		String reg = dh.selectregister();
		dbLoading = reg.equals("0");

		if (dbLoading) {
			dh.update2("1");
			dh.insertLanguage("English");
		}

		pbDownload.setProgress(0);
		loadPosition = 0;

		(new Thread(new Runnable() {

			public void run() {
				try {
					final int delay = 800;

					TimeUnit.MILLISECONDS.sleep(1);

					if (dbLoading) {
						dh.clearTableName3();
						dh.clearTableName4();
					}

					String str1, str2;
					try {
						str1 = getStringFromRawFile();
					} catch (IOException e) {
						str1 = "";
					}
					try {
						str2 = getStringFromRawFile2();
					} catch (IOException e) {
						str2 = "";
					}

					tbl3 = str1.split("\\#");
					tbl4 = str2.split("\\#");

					onLoad.sendEmptyMessage(0);

					int l = tbl3.length;
					for (int i = 0; i < l; ++i) {
						if (dbLoading) {
							dh.addTableName3row(tbl3[i]);
						}
						ht3.sendEmptyMessage(i);
						TimeUnit.MICROSECONDS.sleep(delay);
					}

					l = tbl4.length;
					for (int i = 0; i < l; ++i) {
						if (dbLoading) {
							dh.addTableName4row(tbl4[i]);
						}
						ht4.sendEmptyMessage(i);
						TimeUnit.MICROSECONDS.sleep(delay);
					}
				} catch (Exception e) {
					pbDownload.setProgress(0);
				}

				onLoadComplete.sendEmptyMessage(0);

			}
		})).start();
	}

	public void goNext() {
		
		String res = dh.select15();
		if (res.equals("1")) {
			Intent I = new Intent(getApplicationContext(),
					Activity_MainMenu.class);
			startActivity(I);
			finish();
		} else {
			Intent I = new Intent(getApplicationContext(),
					Activity_Settings.class);
			startActivity(I);
			finish();
		}
		
		
	}

	public DataHelper getDataHelper() {
		return new DataHelper(this);
	}

}