﻿package com.skf.vibracon.selection;

/*
 superslon74@gmail.com
 skype - superslon74
 schamanskij gennadij aleksandrovich
 */

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;

public class DataHelper {
	private static final String DATABASE_NAME = "trt6333.db";
	private static final int DATABASE_VERSION = 1;
	private static final String TABLE_NAME = "user";
	private static final String TABLE_NAME2 = "metric";
	private static final String TABLE_NAME3 = "equipment";
	private static final String TABLE_NAME4 = "vibracon";
	private static final String TABLE_NAME6 = "proba2";
	private static final String TABLE_NAME5 = "register";
	private static final String TABLE_NAME7 = "machinefactor";
	private static final String TABLE_NAME9 = "historys";
	private static final String TABLE_NAME10 = "imp";
	private static final String TABLE_NAME11 = "countrys";
	private static final String TABLE_NAME12 = "dealers";
	private static final String TABLE_NAME13 = "registeruser";
	private static final String TABLE_NAME14 = "language";
	private static final String TABLE_NAME15 = "registr1";
	private static final String TABLE_NAME16 = "registr2";
	
	public static final int Measurement_Metric = 0;
	public static final int Measurement_Imperial= 1;
	

	/*
	 * private static final String TABLE_NAME6 = "manyK";
	 */private Context context;
	private SQLiteDatabase db;

	public DataHelper(Context context) {
		this.context = context;
		OpenHelper openHelper = new OpenHelper(this.context);
		this.db = openHelper.getWritableDatabase();
	}

	public long insert(String company, String name, String phone, String email) {
		ContentValues cv = new ContentValues();
		cv.put("company", company);
		cv.put("name", name);
		cv.put("phone", phone);
		cv.put("email", email);
		return this.db.insert(TABLE_NAME, null, cv);
	}

	public void deletehistory(String data1, String model, String sumorder,
			String id, String status, String maxload) {
	
		String table = TABLE_NAME9;
		String whereClause = "id='" + id + "'";
			String[] whereArgs = null;
		db.delete(table, whereClause, whereArgs);

	}

	public void deleteallhistory() {
		this.db.execSQL("DELETE from " + TABLE_NAME9 + ";");
	}

	public String selectLanguage() {

		Cursor cursor = this.db
				.query(TABLE_NAME14, new String[] { "language" }, null, null,
						null, null, null, null);

		String strt = "";
		if (cursor.moveToFirst()) {
			do {
				strt = cursor.getString(0);
			} while (cursor.moveToNext());
		}
		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}
		return strt;
	}

	public void insertLanguage(String strt) {
		this.db.execSQL("DELETE from " + TABLE_NAME14 + ";");

		ContentValues cv = new ContentValues();
		cv.put("language", strt);

		this.db.insert(TABLE_NAME14, null, cv);

	}

	public void clearTableName3() {
		this.db.execSQL("DELETE from " + TABLE_NAME3 + ";");
	}

	public void addTableName3row(String row) {
		String[] res = row.split("\\|");

		String A1 = res[0];
		String A2 = res[1];
		String A3 = res[2];
		String B1 = res[3];
		String B2 = res[4];
		String B3 = res[5];
		String B4 = res[6];

		String[] result3 = B1.split("\\;");
		String[] result4 = B2.split("\\;");
		String A4 = result3[0];
		String A5 = result3[1];
		String A6 = result3[2];
		String A7 = result4[0];
		String A8 = result4[1];
		String A9 = result4[2];

		String[] result5 = B3.split("\\;");
		String A10 = result5[0];
		String A11 = result5[1];
		String A12 = result5[2];
		String A13 = result5[3];
		String A14 = B4;

		ContentValues cv = new ContentValues();
		cv.put("object", A1);
		cv.put("make", A2);
		cv.put("type", A3);
		cv.put("kn", A4);
		cv.put("kw", A5);
		cv.put("speed", A6);
		cv.put("number", A7);
		cv.put("diametr", A8);
		cv.put("diametrb", A9);
		cv.put("weightwater", "0");
		cv.put("weightlubricant", "0");
		cv.put("totwidth", A10);
		cv.put("boltpitch", A11);
		cv.put("foundinside", A12);
		cv.put("machineinside", A13);
		cv.put("fitterbolt",A14);
		this.db.insert(TABLE_NAME3, null, cv);
	}

	
	
	
	public void insert2(String strt) {
		this.db.execSQL("DELETE from " + TABLE_NAME3 + ";");

		String[] plot2 = strt.split("\\#");

		int A = plot2.length;
		for (int i = 0; i < A; i++) {

			String[] res = plot2[i].split("\\|");

			String A1 = res[0];
			String A2 = res[1];
			String A3 = res[2];
			String B1 = res[3];
			String B2 = res[4];
			String B3 = res[5];

			String[] result3 = B1.split("\\;");
			String[] result4 = B2.split("\\;");
			String A4 = result3[0];
			String A5 = result3[1];
			String A6 = result3[2];
			String A7 = result4[0];
			String A8 = result4[1];
			String A9 = result4[2];

			String[] result5 = B3.split("\\;");
			String A10 = result3[0];
			String A11 = result3[1];
			String A12 = result3[2];
			String A13 = result4[3];

			ContentValues cv = new ContentValues();
			cv.put("object", A1);
			cv.put("make", A2);
			cv.put("type", A3);
			cv.put("kn", A4);
			cv.put("kw", A5);
			cv.put("speed", A6);
			cv.put("number", A7);
			cv.put("diametr", A8);
			cv.put("diametrb", A9);
			cv.put("weightwater", "0");
			cv.put("weightlubricant", "0");
			cv.put("totwidth", A10);
			cv.put("boltpitch", A11);
			cv.put("foundinside", A12);
			cv.put("machineinside", A13);

			this.db.insert(TABLE_NAME3, null, cv);

		}
	}

	public void clearTableName4() {
		this.db.execSQL("DELETE from " + TABLE_NAME4 + ";");
	}

	public void addTableName4row(String row) {
		String[] res = row.split("\\|");

		String A1 = res[0];
		// String A2=res[1];
		int A2 = Integer.parseInt(res[1].replaceAll("[^0-9]", ""));

		String A3 = res[2];
		String A4 = res[3];
		String A5 = res[4];
		// String A6=res[5];
		int A6 = Integer.parseInt(res[5].replaceAll("[^0-9]", ""));

		String A7 = res[6];
		String A8 = res[7];
		String A9 = res[8];
		String A10 = res[9];
		String A11 = res[10];
		String A12 = res[11];
		String A13 = res[12];
		String A14 = res[13];
		String A15 = res[14];
		String A16 = res[15];
		String A17 = res[16];
		String A18 = res[17];
		String A19 = res[18];
		String A20 = res[19];
		String A21 = res[20];
		String A22 = res[21];
		ContentValues cv = new ContentValues();

		cv.put("vibracontype", A1);
		cv.put("boltsize1", A2);
		cv.put("boltsize1imp", A3);
		cv.put("torgue1", A4);
		cv.put("torgue1imp", A5);
		cv.put("boltsize2", A6);
		cv.put("boltsize2imp", A7);
		cv.put("torgue2", A8);
		cv.put("torgue2imp", A9);
		cv.put("machineload", A10);
		cv.put("maxelementloade", A11);
		cv.put("minimumheight", A12);
		cv.put("nominalheight", A13);
		cv.put("maximumheight", A14);
		cv.put("minreducedheight", A15);
		cv.put("maxextendedheight", A16);
		cv.put("bolthole", A17);
		cv.put("diameterhole", A18);
		cv.put("keyholes", A19);
		cv.put("pitch", A20);
		cv.put("mass", A21);
		cv.put("typ", A22);
		this.db.insert(TABLE_NAME4, null, cv);
	}

	public void insert3(String strt) {
		this.db.execSQL("DELETE from " + TABLE_NAME4 + ";");

		String[] plot2 = strt.split("\\#");

		int A = plot2.length;
		for (int i = 0; i < A; i++) {

			String[] res = plot2[i].split("\\|");

			String A1 = res[0];
			// String A2=res[1];
			int A2 = Integer.parseInt(res[1].replaceAll("[^0-9]", ""));

			String A3 = res[2];
			String A4 = res[3];
			String A5 = res[4];
			// String A6=res[5];
			int A6 = Integer.parseInt(res[5].replaceAll("[^0-9]", ""));

			String A7 = res[6];
			String A8 = res[7];
			String A9 = res[8];
			String A10 = res[9];
			String A11 = res[10];
			String A12 = res[11];
			String A13 = res[12];
			String A14 = res[13];
			String A15 = res[14];
			String A16 = res[15];
			String A17 = res[16];
			String A18 = res[17];
			String A19 = res[18];
			String A20 = res[19];
			String A21 = res[20];
			String A22 = res[21];
			ContentValues cv = new ContentValues();

			cv.put("vibracontype", A1);
			cv.put("boltsize1", A2);
			cv.put("boltsize1imp", A3);
			cv.put("torgue1", A4);
			cv.put("torgue1imp", A5);
			cv.put("boltsize2", A6);
			cv.put("boltsize2imp", A7);
			cv.put("torgue2", A8);
			cv.put("torgue2imp", A9);
			cv.put("machineload", A10);
			cv.put("maxelementloade", A11);
			cv.put("minimumheight", A12);
			cv.put("nominalheight", A13);
			cv.put("maximumheight", A14);
			cv.put("minreducedheight", A15);
			cv.put("maxextendedheight", A16);
			cv.put("bolthole", A17);
			cv.put("diameterhole", A18);
			cv.put("keyholes", A19);
			cv.put("pitch", A20);
			cv.put("mass", A21);
			cv.put("typ", A22);
			this.db.insert(TABLE_NAME4, null, cv);
		}

	}

	public long insert4() {
		ContentValues cv = new ContentValues();
		cv.put("vibracontype", "company");
		cv.put("boltsize1", "name");
		cv.put("boltsize1imp", "phone");

		return this.db.insert(TABLE_NAME6, null, cv);
	}

	public int insert5(String model, String maxload, String sumorder,
			String status, String project) {
		int res = 0;
		String str = selectAll12();
		if (str == "no registered user") {
			res = 0;
		} else {
			res = 1;
		}
		if (res == 1) {
			String[] ss = str.split("\\|");
			ContentValues cv = new ContentValues();

			String company = ss[0];
			String name = ss[1];
			String phone = ss[2];
			String email = ss[3];

			cv.put("company", company);
			cv.put("name", name);
			cv.put("phone", phone);
			cv.put("email", email);
			cv.put("model", model);
			cv.put("maxload", maxload);
			cv.put("sumorder", sumorder);
			cv.put("status", status);
			// data1 TEXT,data2 TEXT)");
			Calendar c = Calendar.getInstance();
			SimpleDateFormat df = new SimpleDateFormat("dd.mm.yyyy");
			String data1 = df.format(c.getTime());
			cv.put("data1", data1);
			cv.put("data2", "0");
			cv.put("project", project);

			this.db.insert(TABLE_NAME9, null, cv);

		}
		return res;
	}

	public String selectAll12() {

		Cursor cursor = this.db.query(TABLE_NAME, new String[] { "company",
				"name", "phone", "email" }, null, null, null, null, null, null);

		String strt = "";
		if (cursor.moveToFirst()) {
			do {
				strt = cursor.getString(0) + "|" + cursor.getString(1) + "|"
						+ cursor.getString(2) + "|" + cursor.getString(3);
			} while (cursor.moveToNext());
		} else {
			strt = "no registered user";
		}

		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}
		return strt;
	}

	public long update(String name, String metricsystems) {
		ContentValues cv = new ContentValues();
		cv.put("name", name);
		cv.put("metricsystems", metricsystems);

		this.db.execSQL("DELETE from " + TABLE_NAME2 + ";");
		// ");
		return this.db.insert(TABLE_NAME2, null, cv);
	}

	// *************************************************************
	public long update15(String name) {
		ContentValues cv = new ContentValues();
		cv.put("regis", name);
		this.db.execSQL("DELETE from " + TABLE_NAME15 + ";");
		return this.db.insert(TABLE_NAME15, null, cv);
	}

	public long update16(String name) {
		ContentValues cv = new ContentValues();
		cv.put("regis", name);
		this.db.execSQL("DELETE from " + TABLE_NAME16 + ";");
		return this.db.insert(TABLE_NAME16, null, cv);
	}

	// ***********************************

	public String select15() {
		Cursor cursor = this.db.query(TABLE_NAME15, new String[] { "regis" },
				null, null, null, null, null, null);
		String strt = "";
		if (cursor.moveToFirst()) {
			do {
				strt = cursor.getString(0);
			} while (cursor.moveToNext());
		}
		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}
		return strt;
	}

	public String select16() {
		Cursor cursor = this.db.query(TABLE_NAME16, new String[] { "regis" },
				null, null, null, null, null, null);
		String strt = "";
		if (cursor.moveToFirst()) {
			do {
				strt = cursor.getString(0);
			} while (cursor.moveToNext());
		}
		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}
		return strt;
	}

	// *************************************************
	public long update2(String register) {
		ContentValues cv = new ContentValues();
		cv.put("fact", register);

		this.db.execSQL("DELETE from " + TABLE_NAME13 + ";");
		// ");
		return this.db.insert(TABLE_NAME13, null, cv);
	}

	public String selectregister() {
		Cursor cursor = this.db.query(TABLE_NAME13, new String[] { "fact" },
				null, null, null, null, null, null);
		String strt = "";
		if (cursor.moveToFirst()) {
			do {
				strt = cursor.getString(0);
			} while (cursor.moveToNext());
		}
		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}
		return strt;
	}

	public void deleteAll() {
		this.db.delete(TABLE_NAME, null, null);
	}

	public void deleteAll2() {
		this.db.delete(TABLE_NAME2, null, null);
	}

	public void deleteAll3() {
		this.db.delete(TABLE_NAME3, null, null);
	}

	public List<String> selectAll() {
		List<String> list = new ArrayList<String>();
		Cursor cursor = this.db.query(TABLE_NAME, new String[] { "company",
				"name", "phone", "email" }, null, null, null, null, null, null);

		String strt = "";
		if (cursor.moveToFirst()) {
			do {
				strt = cursor.getString(0) + "|" + cursor.getString(1) + "|"
						+ cursor.getString(2) + "|" + cursor.getString(3);

			} while (cursor.moveToNext());

			list.add(strt);
		} else {
			list.add("no registered user");

		}

		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}
		return list;
	}

	public List<String> selectAllLanguage() {
		List<String> list = new ArrayList<String>();
		Cursor cursor = this.db.query(TABLE_NAME, new String[] { "company",
				"name", "phone", "email" }, null, null, null, null, null, null);

		String strt = "";
		if (cursor.moveToFirst()) {
			do {
				strt = cursor.getString(0) + "|" + cursor.getString(1) + "|"
						+ cursor.getString(2) + "|" + cursor.getString(3);

			} while (cursor.moveToNext());

			list.add(strt);
		} else {
			list.add("no registered user");

		}

		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}
		return list;
	}

	public List<String> selectAll2() {
		List<String> list = new ArrayList<String>();
		Cursor cursor = this.db.query(TABLE_NAME2, new String[] { "name",
				"metricsystems", "phone", "email" }, null, null, null, null,
				null, null);

		if (cursor.moveToFirst()) {
			do {

				list.add(cursor.getString(0));

			} while (cursor.moveToNext());
		}

		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}
		return list;
	}

	public List<String> selectAll3() {
		List<String> list = new ArrayList<String>();
		String orderBy = "object";
		Cursor cursor = this.db.query(TABLE_NAME3, new String[] { "object",
				"make", "type", "kn", "kw", "speed", "number", "diametr",
				"diametrb", "weightwater", "weightlubricant" }, null, null,
				null, null, orderBy);
		if (cursor.moveToFirst()) {
			do {

				list.add(cursor.getString(0));

			} while (cursor.moveToNext());
		}

		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}

		return list;
	}

	public List<String> selectAll33() {
		List<String> list = new ArrayList<String>();

		Cursor cursor = this.db.query(TABLE_NAME11, new String[] { "country",
				"id1" }, null, null, null, null, null);
		if (cursor.moveToFirst()) {
			do {

				list.add(cursor.getString(0) + "|" + cursor.getString(1));

			} while (cursor.moveToNext());
		}

		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}

		return list;
	}

	public List<String> selectAll333(String str) {
		List<String> list = new ArrayList<String>();

		String selection = "id1=?";
		String[] selectionArgs = new String[] { str };

		Cursor cursor = this.db.query(TABLE_NAME12, new String[] { "city",
				"adress", "phone", "email", "url", "latitude", "longitude",
				"id1" }, selection, selectionArgs, null, null, null);
		if (cursor.moveToFirst()) {
			do {

				list.add(cursor.getString(0) + "|" + cursor.getString(1) + "|"
						+ cursor.getString(2) + "|" + cursor.getString(3) + "|"
						+ cursor.getString(4) + "|" + cursor.getString(5) + "|"
						+ cursor.getString(6) + "|");

			} while (cursor.moveToNext());
		}

		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}

		return list;
	}

	public String selectAll41(String str1, String str2, String str3) {

		String selection = "object=? and make=? and type=?";
		String[] selectionArgs = new String[] { str1, str2, str3 };
		String str = "";

		Cursor cursor = this.db.query(TABLE_NAME3, new String[] { "kn", "kw",
				"speed", "number", "diametr", "diametrb","boltpitch" }, selection,
				selectionArgs, null, null, null);
		if (cursor.moveToFirst()) {
			do {

				str = cursor.getString(0) + "|" + cursor.getString(1) + "|"
						+ cursor.getString(2) + "|" + cursor.getString(3) + "|"
						+ cursor.getString(4) + "|" + cursor.getString(5) + 
						"|" + cursor.getString(6) + "|";

			} while (cursor.moveToNext());
		}

		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}

		return str;
	}

	public List<String> selectAll4(String str) {
		List<String> list = new ArrayList<String>();
		String selection = "object=?";
		String[] selectionArgs = new String[] { str };
		Cursor cursor = this.db.query(TABLE_NAME3, new String[] { "object",
				"make", "type", "kn", "kw", "speed", "number", "diametr",
				"diametrb", "weightwater", "weightlubricant" }, selection,
				selectionArgs, null, null, null);
		if (cursor.moveToFirst()) {
			do {

				list.add(cursor.getString(1));

			} while (cursor.moveToNext());
		}

		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}

		return list;
	}

	public List<String> selectAll5(String str, String str2) {
		List<String> list = new ArrayList<String>();
		String selection = "object=? and make=?";
		String[] selectionArgs = new String[] { str, str2 };
		Cursor cursor = this.db.query(TABLE_NAME3, new String[] { "object",
				"make", "type", "kn", "kw", "speed", "number", "diametr",
				"diametrb", "weightwater", "weightlubricant" }, selection,
				selectionArgs, null, null, null);
		if (cursor.moveToFirst()) {
			do {

				list.add(cursor.getString(2));

			} while (cursor.moveToNext());
		}

		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}

		return list;
	}

	public String konvert(String str) {
		String result = null;
	Hashtable<String, String> table = new Hashtable<String, String>();
		table.put("0.5", "12");
		table.put("0.5625", "14");
		table.put("0.625", "16");
		table.put("0.75", "20");
		table.put("1", "24");
		table.put("1.125", "30");
		table.put("1.25", "33");
		table.put("1.375", "36");
		table.put("0.75", "20");
		table.put("1", "24");
		table.put("1.25", "30");
		table.put("1.375", "36");
		table.put("1.5", "39");
		table.put("1.75", "45");
		table.put("2", "52");
		table.put("2.25", "56");
		table.put("2.5", "64");
		table.put("2.75", "68");
		result=table.get(str);
		return result;
}
	
	public String selectAll6(String str1, String str2, String str3) {
		String Error = "";
		String str = null;
		String selection = "object=? and make=? and type=?";
		String[] selectionArgs = new String[] { str1, str2, str3 };
		Cursor cursor = this.db.query(TABLE_NAME3, new String[] { "object",
				"make", "type", "kn", "kw", "speed", "number", "diametr",
				"diametrb", "weightwater", "weightlubricant", "boltpitch",
				"fitterbolt" }, selection, selectionArgs, null, null, null);
		if (cursor.moveToFirst()) {
			do {

				str = cursor.getString(0) + "|" + cursor.getString(3) + "|"
						+ cursor.getString(4) + "|" + cursor.getString(5) + "|"
						+ cursor.getString(6) + "|" + cursor.getString(7) + "|"
						+ cursor.getString(8) + "|" + cursor.getString(11)
						+ "|" + cursor.getString(12) + "|";

			} while (cursor.moveToNext());
		}

		String[] plot2 = str.split("\\|");

		String A1 = plot2[0];// compressor
		// Integer.parseInt(str);
		double mass = 0;
		double power = 0;
		double speed = 0;
		int holes = 0;
		int A6 = 0;
		String A7 = plot2[6];
		double pitch = 0;// .6;
		int number = 0;
		try {
			mass = Double.parseDouble(plot2[1].replaceAll("[^0-9]", "")) * 9.81;// mass
			power = Double.parseDouble(plot2[2].replaceAll("[^0-9]", ""));// power
			speed = Double.parseDouble(plot2[3].replaceAll("[^0-9]", ""));// speed
			holes = Integer.parseInt(plot2[4].replaceAll("[^0-9]", ""));// holes
			A6 = Integer.parseInt(plot2[5].replaceAll("[^0-9]", ""));//
			// A7 = plot2[6];
			pitch = Double.parseDouble(plot2[7]);// .replaceAll("[^0-9]",
													// ""));//pitch
			number = Integer.parseInt(plot2[8]);// .replaceAll("[^0-9]", ""));
		} catch (java.lang.NumberFormatException e) {
			Error = "Error";

		}
		
		if (Error != "Error") {
		double weight = (mass / holes) * 0.001;
		double torque = (power * 60) / (2 * 3.14 * speed);

		double force = ((torque * 0.5) * 0.001 * pitch);
		double dinamicforce = force / holes;

		double max = (weight + dinamicforce);
		//double min = (max - dinamicforce);
		// String asd=A1+"|"+max+"|"+min+"|"+A6+"|"+A7+"|";

		String res = "";
		double C = 0;
		if (A1 == "Engine") {
			C = 2;
		} else if (A1 == "Gearbox") {
			C = 1.25;
		} else if (A1 == "Step-up gearbox") {
			C = 1.25;
		} else if (A1 == "Engine Skid") {
			C = 2;
		} else if (A1 == "Rudder Engine") {
			C = 2;
		} else if (A1 == "Piston enngine") {
			C = 2;
		} else if (A1 == "Steam engine") {
			C = 2;
		} else if (A1 == "Gearbox fifi-pump") {
			C = 2;
		} else {
			C = 1.5;
		}

		//
		int df = (int) (max * C);
		String A71=null;
		double a7=Double.parseDouble(A7);
		if(a7>3){
			A71=A7;
		} else
		{
			A71=konvert(A7);
		}
		
		
		String asd = "" + df + "|" + A71 + "|";
		String sdf = selectAll11("" + A71, "" + df) + (holes-number);

		//return asd;
		 return sdf;

		
		} else return "Error";
		
	}

	public String selectAll7(String str,String boltpish,String fitterbolts2) {
		String[] plot2 = str.split("\\|");
		String A1 = plot2[0];
		int fitterbolts=(int)(Integer.parseInt(fitterbolts2.replaceAll("[^0-9]", "")));
		int mass = (int) (Integer.parseInt(plot2[1].replaceAll("[^0-9]", "")) * 9.81);
		int power = Integer.parseInt(plot2[2].replaceAll("[^0-9]", ""));
		int speed = Integer.parseInt(plot2[3].replaceAll("[^0-9]", ""));
		int holes = Integer.parseInt(plot2[4].replaceAll("[^0-9]", ""));
		int weight = (int)((mass / holes)*0.001);
		int torque = (int) ((int) (power * 60) / (2 * 3.14 * speed));
		int A8 = 1;
		double pitch=Double.parseDouble(boltpish);
		int totalforce = (int) ((torque * 0.5)*0.001*pitch);// ;
		int A6 = Integer.parseInt(plot2[5].replaceAll("[^0-9]", ""));
		int A7 = Integer.parseInt(plot2[6].replaceAll("[^0-9]", ""));

		int dinamicforce = totalforce / holes;
		int max = (int) (weight + dinamicforce);
			String res = "";
		double C = 0;
		if (A1 == "Engine") {
			C = 2;
		} else if (A1 == "Gearbox") {
			C = 1.25;
		} else if (A1 == "Step-up gearbox") {
			C = 1.25;
		} else if (A1 == "Engine Skid") {
			C = 2;
		} else if (A1 == "Rudder Engine") {
			C = 2;
		} else if (A1 == "Piston enngine") {
			C = 2;
		} else if (A1 == "Steam engine") {
			C = 2;
		} else if (A1 == "Gearbox fifi-pump") {
			C = 2;
		} else {
			C = 1.5;

		}

		int df = (int) (max * C);

		String asd = "" + df + "|" + A7 + "|";
		String sdf = selectAll11("" + A7, "" + df) + (holes-fitterbolts);
		return sdf;
	}

	public String selectAll72(String str,String boltpish) {
		String[] plot2 = str.split("\\|");
		String A1 = plot2[0];
		int mass = (int) (Integer.parseInt(plot2[1].replaceAll("[^0-9]", "")) * 9.81* 0.45359);
		int power = (int) (Integer.parseInt(plot2[2].replaceAll("[^0-9]", ""))* 0.74569);
		int speed = Integer.parseInt(plot2[3].replaceAll("[^0-9]", ""));
		int holes = Integer.parseInt(plot2[4].replaceAll("[^0-9]", ""));
		int weight =(int)((mass / holes)*0.001);
		int torque = (int) ((int) (power * 60) / (2 * 3.14 * speed));
		int A8 = 1;
		double pitch=Double.parseDouble(boltpish)* 0.03937;
		
		int totalforce = (int) ((torque * 0.5)*0.001*pitch);// ;
		int A6 = Integer.parseInt(plot2[5].replaceAll("[^0-9]", ""));
		int A7 = Integer.parseInt(plot2[6].replaceAll("[^0-9]", ""));

		int dinamicforce = totalforce / holes;
		int max = (int) ((weight) + dinamicforce);
		
		String res = "";
		double C = 0;
		if (A1 == "Engine") {
			C = 2;
		} else if (A1 == "Gearbox") {
			C = 1.25;
		} else if (A1 == "Step-up gearbox") {
			C = 1.25;
		} else if (A1 == "Engine Skid") {
			C = 2;
		} else if (A1 == "Rudder Engine") {
			C = 2;
		} else if (A1 == "Piston enngine") {
			C = 2;
		} else if (A1 == "Steam engine") {
			C = 2;
		} else if (A1 == "Gearbox fifi-pump") {
			C = 2;
		} else {
			C = 1.5;

		}

		int df = (int) (max * C);

		String asd = selectAll1111(plot2[6]);
		String sdf = selectAll111("" + asd, "" + df) + holes;

		return sdf;
	}

	public List<String> selectAll8() {

		List<String> list = new ArrayList<String>();
		Cursor cursor = this.db.query(TABLE_NAME4, new String[] {
				"vibracontype", "machineload" }, null, null, null, null, null,
				null);

		if (cursor.moveToFirst()) {
			do {

				list.add(cursor.getString(0) + "|" + cursor.getString(1) + "|");

			} while (cursor.moveToNext());
		}

		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}

		return list;

	}

	public List<String> selectAllTypVibraconSMorSMLP(int a) {

		List<String> list = new ArrayList<String>();
		Cursor cursor = this.db.query(TABLE_NAME4, new String[] {
				"vibracontype", "machineload" ,"typ"}, null, null, null, null, null,
				null);

		if (cursor.moveToFirst()) {
			do {
				if(a==1){
				if(cursor.getString(2).equals("1"))
						{	
				list.add(cursor.getString(0) + "|" + cursor.getString(1) + "|");
						}
				} else
				{
					if(cursor.getString(2).equals("2"))
					{	
			list.add(cursor.getString(0) + "|" + cursor.getString(1) + "|");
					}
					
				}
			} while (cursor.moveToNext());
		}

		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}

		return list;

	}
	
	
	
	public List<String> selectAll9() {

		List<String> list = new ArrayList<String>();
		Cursor cursor = this.db.query(TABLE_NAME6, new String[] {
				"vibracontype", "boltsize1", "boltsize1imp" }, null, null,
				null, null, null, null);

		if (cursor.moveToFirst()) {
			do {

				list.add(cursor.getString(0) + "|" + cursor.getString(1) + "|"
						+ cursor.getString(2));

			} while (cursor.moveToNext());
		}

		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}

		return list;

	}

	public String selectAll20() {

		Cursor cursor = this.db.query(TABLE_NAME2, new String[] { "name",
				"metricsystems" }, null, null, null, null, null, null);

		String strt = "";
		if (cursor.moveToFirst()) {
			do {
				strt = cursor.getString(1);

			} while (cursor.moveToNext());

		}
		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}
		return strt;
	}

	public String selectAll11(String str1, String str2) {
		String selection = "boltsize1=? or boltsize2=?";

		String[] selectionArgs = new String[] { str1, str1 };
		int speed2 = Integer.parseInt(str2);
		int boltsize = Integer.parseInt(str1);
		String str = "";
		List<String> list = new ArrayList<String>();
		// String list="+++";
		Cursor cursor = this.db.query(TABLE_NAME4,
				new String[] { "vibracontype", "machineload", "boltsize1",
						"boltsize2", "typ" }, null, null, null, null, null);
		int flag = 0;
		if (cursor.moveToFirst()) {
			do {
				// list.add(cursor.getString(0)+"|"+cursor.getString(1));
				// str=""+cursor.getString(1)+"";
				int as = cursor.getInt(1);

				int boltsize1 = cursor.getInt(2);
				int boltsize2 = cursor.getInt(3);

				if (as >= speed2) {
					if (boltsize <= boltsize1 || boltsize <= boltsize2) {
						if (flag == 0) {
							str = cursor.getString(0) + "|"
									+ cursor.getString(1) + "|"
									+ cursor.getString(4) + "|";
							flag++;
						}
					}
				}
			} while (cursor.moveToNext());
		}

		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}

		return str;
	}

	public String selectAll1111(String str1) {

		String name = "";
		String[] selectionArgs = new String[] { str1 };
		Cursor cursor = this.db.query(TABLE_NAME10, new String[] { "name",
				"imp" }, null, null, null, null, null);
		int flag = 0;
		if (cursor.moveToFirst()) {
			do {
				if (str1.equals(cursor.getString(1))) {
					name = cursor.getString(0);
				}
			} while (cursor.moveToNext());
		}
		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}

		return name;
	}

	public String selectAllimp2(String str1) {

		String name = "";
		String[] selectionArgs = new String[] { str1 };
		Cursor cursor = this.db.query(TABLE_NAME10, new String[] { "imp",
				"name" }, null, null, null, null, null);
		int flag = 0;
		if (cursor.moveToFirst()) {
			do {
				if (str1.equals(cursor.getString(1))) {
					name = cursor.getString(0);
				}
			} while (cursor.moveToNext());
		}
		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}

		return name;
	}

	public String selectAllimp(String str1) {
		double imp = Double.parseDouble(str1);

		List<String> list = new ArrayList<String>();
		Cursor cursor = this.db.query(TABLE_NAME10, new String[] { "name",
				"imp" }, null, null, null, null, null);
		int flag = 0;
		if (cursor.moveToFirst()) {
			do {

				list.add(cursor.getString(0));

			} while (cursor.moveToNext());
		}
		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}
		int ns = list.size();

		final String[] objects = new String[ns];// = names;

		int s = 0;
		for (String name : list) {
			objects[s] = name;
			s++;
		}
		Set<String> set = new HashSet<String>(Arrays.asList(objects));
		String[] result2 = set.toArray(new String[set.size()]);
		int ssd = result2.length;
		final String[] result = new String[ssd];

		for (int j = 0; j < result2.length; j++) {

			for (int i = j + 1; i < result2.length; i++) {
				if (result2[i].compareTo(result2[j]) < 0) {
					String t = result2[j];
					result2[j] = result2[i];
					result2[i] = t;
				}
			}
			result[j] = result2[j];

		}
		// result

		String results = "";
		for (int i = 0; i < result.length; i++) {
			double imp2 = Double.parseDouble(result[i]);

			if (imp > imp2) {
				results = "" + imp2;
			}
		}

		return results;
	}

	public String selectAll111(String str1, String str2) {
		int speed2 = Integer.parseInt(str2);
		double boltsizeimp = Double.parseDouble(str1);
		String str = "";
		List<String> list = new ArrayList<String>();
		// String list="+++";
		Cursor cursor = this.db.query(TABLE_NAME4,
				new String[] { "vibracontype", "machineload", "boltsize1imp",
						"boltsize2imp","typ" }, null, null, null, null, null);
		int flag = 0;
		if (cursor.moveToFirst()) {
			do {
				int as = cursor.getInt(1);

				double boltsize1imp = cursor.getDouble(2);
				double boltsize2imp = cursor.getDouble(3);

				if (as >= speed2) {
					if (boltsizeimp <= boltsize1imp
							|| boltsizeimp <= boltsize2imp) {
						if (flag == 0) {
							str = cursor.getString(0) + "|"
									+ cursor.getString(1) + "|"
									+ cursor.getString(4) + "|";
							flag++;
						}
					}
				}
			} while (cursor.moveToNext());
		}

		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}

		return str;
	}

	public String selectAll10(String str1) {

		String selection = "name=?";
		String[] selectionArgs = new String[] { str1 };
		String str = "null2";

		Cursor cursor = this.db.query(TABLE_NAME7, new String[] { "name",
				"korrector" }, null, null, null, null, null, null);

		if (cursor.moveToFirst()) {
			do {

			} while (cursor.moveToNext());
		}

		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}
		return str;

	}

	public long update2(String name, String register) {
		ContentValues cv = new ContentValues();

		cv.put("name", name);
		cv.put("register", register);

		this.db.execSQL("DELETE from " + TABLE_NAME5 + ";");

		return this.db.insert(TABLE_NAME5, null, cv);
	}

	public String update3() {
		String str = null;
		Cursor cursor = this.db.query(TABLE_NAME5, new String[] { "register",
				"name" }, null, null, null, null, null, null);
		if (cursor.moveToFirst()) {
			do {
				str = cursor.getString(0);
			} while (cursor.moveToNext());
		}
		return str;
	}

	public List<String> selectAll13() {
		List<String> list = new ArrayList<String>();

		Cursor cursor = this.db.query(TABLE_NAME9, new String[] { "data1",
				"model", "sumorder", "project", "status", "maxload", "id" },
				null, null, null, null, null, null);

		String strt = "";
		if (cursor.moveToFirst()) {
			do {
				list.add(cursor.getString(0) + "|" + cursor.getString(1) + "|"
						+ cursor.getString(2) + "|" + cursor.getString(3) + "|"
						+ cursor.getString(4) + "|" + cursor.getString(5) + "|"
						+ cursor.getString(6) + "|");

			} while (cursor.moveToNext());
		}

		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}

		return list;
	}

	public List<String> selectAll21() {
		List<String> list = new ArrayList<String>();
		List<String> list1 = new ArrayList<String>();
		List<String> list2 = new ArrayList<String>();

		Cursor cursor = this.db.query(TABLE_NAME4, new String[] { "boltsize1",
				"boltsize2" }, null, null, null, null, null, null);

		if (cursor.moveToFirst()) {
			do {

				list1.add(cursor.getString(0));
				list2.add(cursor.getString(1));
				// list1.AddRange(list2);
			} while (cursor.moveToNext());

		}
		list.addAll(list1);
		list.addAll(list2);

		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}
		return list;
	}

	public List<String> selectAll211() {
		List<String> list = new ArrayList<String>();

		Cursor cursor = this.db.query(TABLE_NAME10, new String[] { "imp" },
				null, null, null, null, null);
		if (cursor.moveToFirst()) {
			do {

				list.add(cursor.getString(0));

			} while (cursor.moveToNext());
		}

		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}
		return list;
	}

	public int getMeasurementIndex() {
		String str = selectAll20();
		return Integer.parseInt(str.replaceAll("[^0-9]", ""));
	}

	public void setMeasurementIndex(int Index) {
		if (Index == Measurement_Metric) {
			update("Metric", Integer.toString(Measurement_Metric));
		} else {
			update("Imperial", Integer.toString(Measurement_Imperial));
		}

	}

	private static class OpenHelper extends SQLiteOpenHelper {

		OpenHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {

			db.execSQL("CREATE TABLE "
					+ TABLE_NAME
					+ "(id INTEGER PRIMARY KEY, company TEXT,name TEXT,phone TEXT,email TEXT);");
		
			db.execSQL("CREATE TABLE " + TABLE_NAME2
					+ "(id INTEGER PRIMARY KEY,name TEXT,metricsystems TEXT)");
			db.execSQL("insert into " + TABLE_NAME2
					+ "(name,metricsystems) values('Metric','0')");

		
			db.execSQL("CREATE TABLE "
					+ TABLE_NAME3
					+ "(id INTEGER PRIMARY KEY,object TEXT,make TEXT,type TEXT,kn TEXT,kw TEXT,speed TEXT,number TEXT,diametr TEXT,diametrb TEXT,weightwater TEXT,weightlubricant TEXT,totwidth TEXT,boltpitch TEXT,foundinside TEXT,machineinside TEXT,fitterbolt TEXT)");
			db.execSQL("CREATE TABLE "
					+ TABLE_NAME9
					+ "(id INTEGER PRIMARY KEY,company TEXT,name TEXT,phone TEXT,email TEXT,model TEXT,maxload TEXT,sumorder TEXT,status TEXT,data1 TEXT,data2 TEXT,project TEXT)");

			db.execSQL("CREATE TABLE "
					+ TABLE_NAME4
					+ "(id INTEGER PRIMARY KEY,vibracontype TEXT,boltsize1 INTEGER,boltsize1imp TEXT,torgue1 TEXT,torgue1imp TEXT,boltsize2 INTEGER,boltsize2imp TEXT,torgue2 TEXT,torgue2imp TEXT,machineload TEXT,maxelementloade TEXT,minimumheight TEXT,nominalheight TEXT,maximumheight TEXT,minreducedheight TEXT,maxextendedheight TEXT,bolthole TEXT,diameterhole TEXT,keyholes TEXT,pitch TEXT,mass TEXT,typ TEXT);");
			db.execSQL("CREATE TABLE "
					+ TABLE_NAME6
					+ "(id INTEGER PRIMARY KEY,vibracontype TEXT,boltsize1 TEXT,boltsize1imp TEXT,torgue1 TEXT,torgue1imp TEXT,boltsize2 TEXT,boltsize2imp TEXT,torgue2 TEXT,torgue2imp TEXT,machineload TEXT,maxelementloade TEXT,minimumheight TEXT,nominalheight TEXT,maximumheight TEXT,minreducedheight TEXT,maxextendedheight TEXT,bolthole TEXT,diameterhole TEXT,keyholes TEXT,pitch TEXT,mass TEXT,typ TEXT);");
			db.execSQL("CREATE TABLE " + TABLE_NAME5
					+ "(id INTEGER PRIMARY KEY,name TEXT,register TEXT);");
			db.execSQL("insert into " + TABLE_NAME5
					+ "(name,register) values('no','0');");

			db.execSQL("CREATE TABLE " + TABLE_NAME10
					+ "(id INTEGER PRIMARY KEY,name TEXT,imp TEXT);");
			db.execSQL("insert into " + TABLE_NAME10
					+ "(name,imp) values('0.5','1/2');");
			db.execSQL("insert into " + TABLE_NAME10
					+ "(name,imp) values('0.625','5/8');");
			db.execSQL("insert into " + TABLE_NAME10
					+ "(name,imp) values('0.75','3/4');");
			db.execSQL("insert into " + TABLE_NAME10
					+ "(name,imp) values('1.0','1');");
			db.execSQL("insert into " + TABLE_NAME10
					+ "(name,imp) values('1.125','1-1/8');");
			db.execSQL("insert into " + TABLE_NAME10
					+ "(name,imp) values('1.375','1-3/8');");
			db.execSQL("insert into " + TABLE_NAME10
					+ "(name,imp) values('2.25','2-1/4');");
			db.execSQL("insert into " + TABLE_NAME10
					+ "(name,imp) values('2.5','2-1/2');");
			db.execSQL("insert into " + TABLE_NAME10
					+ "(name,imp) values('0.625','5/8');");
			db.execSQL("insert into " + TABLE_NAME10
					+ "(name,imp) values('0.75','3/4');");
			db.execSQL("insert into " + TABLE_NAME10
					+ "(name,imp) values('0.5625','9/16');");
			db.execSQL("insert into " + TABLE_NAME10
					+ "(name,imp) values('0.875','7/8');");
			db.execSQL("insert into " + TABLE_NAME10
					+ "(name,imp) values('1.25','1-1/4');");
			db.execSQL("insert into " + TABLE_NAME10
					+ "(name,imp) values('1.5','1-1/2');");
			db.execSQL("insert into " + TABLE_NAME10
					+ "(name,imp) values('1.75','1-3/4');");
			db.execSQL("insert into " + TABLE_NAME10
					+ "(name,imp) values('2.0','2');");
			db.execSQL("insert into " + TABLE_NAME10
					+ "(name,imp) values('2.75','2-3/4');");
			db.execSQL("insert into " + TABLE_NAME10
					+ "(name,imp) values('0.875','7/8');");

			db.execSQL("CREATE TABLE " + TABLE_NAME11
					+ "(country TEXT,id1 TEXT)");
			db.execSQL("insert into " + TABLE_NAME11
					+ "(country,id1) values('Africa','1');");
			db.execSQL("insert into " + TABLE_NAME11
					+ "(country,id1) values('Americas','2');");
			db.execSQL("insert into " + TABLE_NAME11
					+ "(country,id1) values('Asia Pacific','3');");
			db.execSQL("insert into " + TABLE_NAME11
					+ "(country,id1) values('Europe','4');");

			db.execSQL("CREATE TABLE "
					+ TABLE_NAME12
					+ "(id1 TEXT,city TEXT,companyname  TEXT,url TEXT,phone TEXT,adress TEXT,email TEXT,indexs TEXT,skype TEXT,contactname TEXT,latitude TEXT,longitude TEXT)");

			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('1','South Africa, Boksburg','Asvcty','','+27118213663','Hughes Business Park 48 Saligna Road, Witfield Boksburg 1459 South Africa','','32435','superslon74','schamansckij g.a.','-26.180175','28.218105');");
			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('2','Argentina, Santa Fe','Asvcty','','+543424841666','Estanislao Zeballos 3635(3000) Santa Fe','','32435','superslon74','schamansckij g.a.','-31.602388','-60.7082');");
			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('2','Canada Ontario','Asvcty','','+19057121600','5777 Coopers Avenue Mississauga CDN-Ontario 442 1R9','','32435','superslon74','schamansckij g.a.','43.63328','-79.659895');");
			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('2','Brazil, S.Paulo','Asvcty','','+551143563545','Av. Capitao Casa 1090 Sao Bernardo do Campo 09812-000 S.Paulo 09812-000 Brasil','','32435','superslon74','schamansckij g.a.','-23.726662','-46.564225');");
			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('2','Mexico, Monterrey','Asvcty','','+528111560310','lle Centuria 211, Edificio 3 Pargue Industrial milenium C.P. 67114 Monterrey-Apodaca Mexico','','32435','superslon74','schamansckij g.a.','25.775392','-100.168841');");
			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('2','USA, Cleveland','Asvcty','','+12163782600','26820 Fargo Avenue Cleveland OH-44146 USA','','32435','superslon74','schamansckij g.a.','41.418385','-81.489784');");

			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('3','Australia, Sydney','Asvcty','','+61297487466','2/107 Beaconsfield Street silverwater NSW 2128 Sydney Australia','','32435','superslon74','schamansckij g.a.','-33.837271','151.037825');");
			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('3','China, Qingdao','Asvcty','','+8653288701660','No. 120 Zhuzhou Road Laoshan District PRC-266101 Qingdao China','','32435','superslon74','schamansckij g.a.','36.068527','120.38332');");
			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('3','India, New Delhi','Asvcty','','+911165640246','16 ,Phase iv Okhla Industrial Estate New Delhi 110020 India','','32435','superslon74','schamansckij g.a.','28.564792','77.289437');");
			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('3','Japan ,Yokohama','Asvcty','','+81454782785','4th Floor Innotech bily. 3-17-6 Shin-Yokohama, Kokoku-ku Yokohama 222-0033 Japan','','32435','superslon74','schamansckij g.a.','35.509383','139.618503');");

			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('3','Malaysia, Kuala Lumpur','Asvcty','','+60340473333','432 ,Jaban Ipon 51200 Kuala Lumpur Malaysia','','32435','superslon74','schamansckij g.a.','3.17981','101.684235');");
			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('3','Philippines ,Mandaluyong','Asvcty','','+6327171724','107 Epifanio Delos Santos Avenue(EDSA) 1550 Mandaluyong City Phillipines','','32435','superslon74','schamansckij g.a.','14.590893','121.050396');");
			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('3','Singapore','Asvcty','','+6562654538','22 Japan Terusan Singapore 619299 Singapore','','32435','superslon74','schamansckij g.a.','1.32026','103.726362');");
			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('3','Thailand ,Bangkok','Asvcty','','+6627699012','797 Rama IX Road Kwang Bagkapi Khet Huaykwang Bangkok 10310 Thailand','','32435','superslon74','schamansckij g.a.','13.733716','100.47575');");

			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('4','Austria ,Judenburg','Asvcty','','+433572825550','Gabethoferst 25 8750 Judenburg Austria','','32435','superslon74','schamansckij g.a.','47.181502','14.668525');");
			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('4','Austria ,St.Michael','Asvcty','','+43384351150','Madstein am Ort 9 8770 St. Michael Austria','','32435','superslon74','schamansckij g.a.','47.35326','15.007213');");
			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('4','Austria ,St.Michael','Asvcty','','+43384351150','Madstein am Ort 9 8770 St. Michael Austria','','32435','superslon74','schamansckij g.a.','48.394419','-4.484103');");
			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('4','Chech Republic , Praha','Asvcty','','+420234642158','Umestanskeho Pivovaru 7 P.D. Box 19 170 04 Praha 7 Czech Republic','','32435','superslon74','schamansckij g.a.','50.106446','14.44867');");
			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('4','Denmark ,Nyburg','Asvcty','','+4565311127','Falsterveq 10a 5800 Nyborg Denmark','','32435','superslon74','schamansckij g.a.','55.315886','10.752929');");
			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('4','Eastern Europe @ Cus','Asvcty','','+432236622070','Iz No-Sud, Str 1 Object 50 2351 Wr. Neudorf Austria','','32435','superslon74','schamansckij g.a.','48.073835','16.329156');");
			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('4','France ,Vernouillet','Asvcty','','+33237422990','23 rue Gustave Eiffel 28500 Vernouillet France','','32435','superslon74','schamansckij g.a.','48.712529','1.371142');");

			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('4','Germany ,Bittingheim-Bissingen','Asvcty','','+4971425930','Robert-Bosch-Strase 11 74321 Bittingheim-Bissingen Germany','','32435','superslon74','schamansckij g.a.','48.940149','9.133626');");
			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('4','Italy ,Verona','Asvcty','','+390458622406','Via mezzacampagna 25/a 37135 Verona Italy','','32435','superslon74','schamansckij g.a.','45.392785','10.987011');");

			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('4','Poland ,Katowice','Asvcty','','+48323527800','Ui-Zimona 41 40-318 Katowice Poland','','32435','superslon74','schamansckij g.a.','50.277534','19.080502');");
			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('4','Netherlands ,Enschede ,Katowice','Asvcty','','+31534321962','Twekkeler-es 28 7547 SM Enschede netherlands','','32435','superslon74','schamansckij g.a.','52.220675','6.839629');");

			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('4','Russia ,Moscow','Asvcty','','+74955101820','Kashirskij proezd 13 115201 Moscow Russia','','32435','superslon74','schamansckij g.a.','55.657786','37.624995');");
			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('4','Spain ,Barcelona','Asvcty','','+34935873510','Pol.Ind Cova Solera C/Paris,1-7,Bajos A 08191 Rubi (Barcelona) Spain','','32435','superslon74','schamansckij g.a.','41.484405','2.02692');");

			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('4','Sweden ,Nacka','Asvcty','','+4684620180','Ryssviksvägen 2, 131 36 Nacka, Sweden','','32435','superslon74','schamansckij g.a.','59.310111','18.136575');");
			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('4','Frauenfeld, Switzerland','Asvcty','','+41527212021','Hungerbüelstrasse 17, 8500 Frauenfeld, Switzerland','','32435','superslon74','schamansckij g.a.','47.562845','8.870984');");

			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('4','Istanbul Turkey','Asvcty','','+902124381163','Turkiye Sanayi Caddesi 34235 Istanbul Turkey','','32435','superslon74','schamansckij g.a.','40.895543','29.206967');");
			db.execSQL("insert into "
					+ TABLE_NAME12
					+ "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('4','United Kingdom, Slough','Asvcty','','+441753696136','83 Buckingham Avenue Slough Berkshire  SL1 4AN, United Kingdom','','32435','superslon74','schamansckij g.a.','51.524472','-0.639142');");

			// db.execSQL("insert into "+TABLE_NAME12+
			// "(id1,city,companyname,url,phone,adress,email,indexs,skype,contactname,latitude,longitude) values('4','United Kingdom, Slough','','+441753696136','Slough 83 Buckingham Avenue Slough Berkshire  SL1 4AN, United Kingdom','','32435','superslon74','schamansckij g.a.','51.524472','-0.639142');");

			db.execSQL("CREATE TABLE " + TABLE_NAME13
					+ "(id INTEGER PRIMARY KEY,fact TEXT);");
			db.execSQL("insert into " + TABLE_NAME13 + "(fact) values('0');");
			db.execSQL("CREATE TABLE " + TABLE_NAME14
					+ "(id INTEGER PRIMARY KEY,language TEXT);");

			db.execSQL("CREATE TABLE " + TABLE_NAME15
					+ "(id INTEGER PRIMARY KEY,regis TEXT)");
			db.execSQL("insert into " + TABLE_NAME15 + "(regis) values('0')");

			db.execSQL("CREATE TABLE " + TABLE_NAME16
					+ "(id INTEGER PRIMARY KEY,regis TEXT)");
			db.execSQL("insert into " + TABLE_NAME16 + "(regis) values('0')");

		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
			db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME2);
			db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME3);
			db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME4);
			db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME5);
			db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME7);
			db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME9);
			db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME10);
			db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME11);
			db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME12);
			db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME13);
			db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME14);
			db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME15);
			db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME16);

			onCreate(db);
		}
	}
}
