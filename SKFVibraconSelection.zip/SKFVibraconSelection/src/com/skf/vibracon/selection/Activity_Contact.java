package com.skf.vibracon.selection;
/*
superslon74@gmail.com
skype - superslon74
schamanskij gennadij aleksandrovich
*/


import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.xmlpull.v1.XmlPullParser;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.skf.vibracon.selection.DataHelper;

public class Activity_Contact extends Activity implements OnClickListener  {
	protected Button button1;
	private DataHelper dh;
	private EditText company_edit,name_edit,phone_edit,email_edit;
	private TextView name_text,phone_text,company_text,email_text;
	
	public final Pattern EMAIL_ADDRESS_PATTERN = Pattern.compile( "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" + "\\@" + "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" + "(" + "\\." + "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" + ")+" ); 
  
	private boolean checkEmail(String email) { return EMAIL_ADDRESS_PATTERN.matcher(email).matches(); }
	
	protected void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
   super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_contact);
    
    company_text = (TextView) findViewById(R.id.company_text);
    name_text = (TextView) findViewById(R.id.name_text);
    phone_text = (TextView) findViewById(R.id.phone_text);
    email_text = (TextView) findViewById(R.id.email_text);
    
    company_edit = (EditText) findViewById(R.id.company_edit);
    name_edit = (EditText) findViewById(R.id.name_edit);
    phone_edit = (EditText) findViewById(R.id.phone_edit);
    email_edit = (EditText) findViewById(R.id.email_edit);
    button1 = (Button) findViewById(R.id.button1);
    button1.setOnClickListener(this);
   
    dh = getDataHelper();

	String language=dh.selectLanguage();
    String[] names = { LanguageTools.company,
			LanguageTools.name,
			LanguageTools.phone, LanguageTools.email,LanguageTools.contact_info};
	String[] values = LanguageTools.getStrings(this, language, names,1);
 
	company_text.setText(values[0]);
	name_text.setText(values[1]);
	phone_text.setText(values[2]);
	email_text.setText(values[3]);
	((TextView) findViewById(R.id.contact_topbar_caption))
	.setText(values[4]);
   
    
    String sd="";
    List<String> names11 = dh.selectAll();
    StringBuilder sb = new StringBuilder();
     for (String name : names11) {
       //sb.append(name + "");
    	 sd=name;
    }
     if(sd=="no registered user"){
	  	
	    }
	    else
	    {
	    	
	  String[] sdf=sd.split("\\|"); 
   // infouser.setText(sdf[1]);
   company_edit.setText(sdf[0]);
    name_edit.setText(sdf[1]);
  phone_edit.setText(sdf[2]);
  int dl2=sdf.length;
 // int dl=sdf[3].length();
  if(dl2==4){  
    email_edit.setText(sdf[3]);
  }
    }
  
  }
  public DataHelper getDataHelper(){
  	return new DataHelper(this);
  }


 	public void onClick(View v){
		 if(v==button1)
		 {
	int registr1=company_edit.getText().toString().length();	
	int registr2=name_edit.getText().toString().length();	
	int registr3=phone_edit.getText().toString().length();	
	int registr4=email_edit.getText().toString().length();	
		if(registr1<1)
		{
			Toast.makeText(
						getApplicationContext(),
						"Company is required",
						Toast.LENGTH_SHORT).show();		
			
		}
		else
		{
			if(registr2<1)
			{
				Toast.makeText(
							getApplicationContext(),
							"Name is required",
							Toast.LENGTH_SHORT).show();		
				
			}
			else
			{	
		
				if(registr3<1)
				{
					Toast.makeText(
								getApplicationContext(),
								"Phone is required",
								Toast.LENGTH_SHORT).show();		
					
				}
				else
				{			
				
				
			 dh = getDataHelper();
			 
		boolean korrekt=checkEmail(email_edit.getText().toString());
		if(registr4<1)korrekt=true;
			 if(korrekt==true){
			 
			   dh.insert(company_edit.getText().toString(),name_edit.getText().toString(),phone_edit.getText().toString(),email_edit.getText().toString());
		   
		//	 Intent intent = new Intent(this,Activity_Settings.class);
		//		startActivity(intent);				 
				finish();
			 }
			 else
			 {
				 Toast.makeText(
 						getApplicationContext(),
 						"E-mail is required",
 						Toast.LENGTH_SHORT).show();				 
				 
				 
			 }
			 
		 } 
		 }
		 }
		 }  

	}
 	@Override
	public void onConfigurationChanged(Configuration newConfig) {  
	        super.onConfigurationChanged(newConfig);  
	}	
 	
 	
}