package com.skf.vibracon.selection;

/*
 superslon74@gmail.com
 skype - superslon74
 schamanskij gennadij aleksandrovich
 */

import java.util.List;

import com.skf.style.SKF_Listcheck_Activity;
import com.skf.vibracon.selection.R;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Activity_History extends SKF_Listcheck_Activity {
	private String[] m_Items;
	 public DataHelper getDataHelper(){
		  	return new DataHelper(this);
		  }
	 private DataHelper dh;
	private View CreateItem(LayoutInflater li, int Index) {
		
		View item = li.inflate(R.layout.listitem_history, null);
		TextView text1 = (TextView) item.findViewById(R.id.model);
		TextView text2 = (TextView) item.findViewById(R.id.number);
		TextView text3 = (TextView) item.findViewById(R.id.nameproject);
		ImageView image=(ImageView) item.findViewById(R.id.image);
		int width = getWindowManager().getDefaultDisplay().getWidth();
        text1.getLayoutParams().width=125;
        text2.getLayoutParams().width=50;
        text3.getLayoutParams().width=width-65-100-125;
        image.getLayoutParams().width=35;
   	
		String str[] = m_Items[Index].split("\\|");
		text1.setText(str[1]);

		text2.setText(str[2]);
		text3.setText(str[3]);
		return item;
		
	}
	
	protected String getCaption() {
		final Intent I = getIntent();
		return "Caption";
	}

	protected int getSelected() {
		return -1;
	}

	protected String[] getItems() {
		List<String> sl = (new DataHelper(this)).selectAll13();
		
		String[] items = new String[sl.size()];
		sl.toArray(items);
		
		return items;
	}
	
	@Override
	protected void createList(String[] items) {
		dh = getDataHelper();
		 String language=dh.selectLanguage();
		    String[] names = { LanguageTools.history};
			String[] values = LanguageTools.getStrings(this, language, names,1);
		
			    ((TextView) findViewById(R.id.skf_topbar_caption))
		 	.setText(values[0]);
		
		
		
		LayoutInflater li = getLayoutInflater();
		final int len = items.length;

		m_Items = items;
		for (int i = 0; i < len; ++i) {

			m_ListController.addView(CreateItem(li, i));
		}
		m_ListController.createList();

	}

	@Override
	protected void doClick(int ItemIndex) {
		
		Intent I = new Intent(this, Activity_DeleteHistory.class);
		I.putExtra("info", m_Items[ItemIndex]);
		
		startActivityForResult(I, 1);
		
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == 1) {
			if (resultCode == RESULT_OK) {
				
				m_ListController.clear();
		//Toast.makeText(this,"????????????????", Toast.LENGTH_SHORT).show();
				
				createList(getItems());
			}
		}
	}
}