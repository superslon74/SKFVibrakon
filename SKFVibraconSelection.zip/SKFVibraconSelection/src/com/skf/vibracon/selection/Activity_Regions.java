package com.skf.vibracon.selection;

/*
 superslon74@gmail.com
 skype - superslon74
 schamanskij gennadij aleksandrovich
 */

import java.util.List;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.TextView;
import android.widget.Toast;

import com.skf.vibracon.selection.DataHelper;

public class Activity_Regions extends Activity implements OnClickListener {

	String regionA,regionB,regionC,regionD; 
	private DataHelper dh;
	private TextView region1,region2,region3,region4;
	public String str=null;
	
	protected void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_regions);
	/*	findViewById(R.id.region_list1).setOnClickListener(this);
		findViewById(R.id.region_list2).setOnClickListener(this);
		findViewById(R.id.region_list3).setOnClickListener(this);
		findViewById(R.id.region_list4).setOnClickListener(this);

		region1 = (TextView) findViewById(R.id.region1);
		region2 = (TextView) findViewById(R.id.region2);
		region3 = (TextView) findViewById(R.id.region3);
		region4 = (TextView) findViewById(R.id.region4);
		dh = getDataHelper();

		String language = dh.selectLanguage();
		String[] names = { LanguageTools.sales_areas };
		String[] values = LanguageTools.getStrings(this, language, names);
		((TextView) findViewById(R.id.sales_areas)).setText(values[0]);
		String[] names2 = { LanguageTools2.africa, LanguageTools2.americas,
				LanguageTools2.asiapacific, LanguageTools2.europe };
		String[] values2 = LanguageTools2.getStrings(this, language, names2);
		((TextView) findViewById(R.id.region1)).setText(values2[0]);
		regions = new String[4];
		regions[0] = values2[0];
		((TextView) findViewById(R.id.region2)).setText(values2[1]);
		regions[1] = values2[1];
		((TextView) findViewById(R.id.region3)).setText(values2[2]);
		regions[2] = values2[2];
		((TextView) findViewById(R.id.region4)).setText(values2[3]);
		regions[3] = values2[3];
	*/
		findViewById(R.id.region_list1).setOnClickListener(this);
		findViewById(R.id.region_list2).setOnClickListener(this);
		findViewById(R.id.region_list3).setOnClickListener(this);
		findViewById(R.id.region_list4).setOnClickListener(this);
		
	    region1 = (TextView) findViewById(R.id.region1);
	    region2 = (TextView) findViewById(R.id.region2);
	    region3 = (TextView) findViewById(R.id.region3);
	    region4 = (TextView) findViewById(R.id.region4);
	    dh = getDataHelper();

		String language=dh.selectLanguage();
	    String[] names = {LanguageTools.sales_areas};
		String[] values = LanguageTools.getStrings(this, language, names,1);
	 	((TextView) findViewById(R.id.sales_areas))
		.setText(values[0]);
	 	String[] names2 = {LanguageTools.africa,LanguageTools.americas,LanguageTools.asiapacific,LanguageTools.europe};
		String[] values2 = LanguageTools.getStrings(this, language, names2,2);
	 	((TextView) findViewById(R.id.region1))
		.setText(values2[0]);
	 	regionA=values2[0];
	 	((TextView) findViewById(R.id.region2))
		.setText(values2[1]);
	 	regionB=values2[1];
	 	((TextView) findViewById(R.id.region3))
		.setText(values2[2]);
	 	regionC=values2[2];
	 	((TextView) findViewById(R.id.region4))
		.setText(values2[3]);
	 	regionD=values2[3];	
		
		
	}

	public DataHelper getDataHelper() {
		return new DataHelper(this);
	}

	public void onClick(View v) {
	/*	int index = -1;
		switch (v.getId()) {
		case R.id.region_list1: {
			index = 0;
			break;
		}
		case R.id.region_list2: {
			index = 1;
			break;
		}
		case R.id.region_list3: {
			index = 2;
			break;
		}
		case R.id.region_list4: {
			index = 3;
			break;
		}
		}

		if (index >= 0) {
			dh = getDataHelper();
			List<String> names2 = this.dh.selectAll333(Integer
					.toString(index + 1));
			int ns = names2.size();
			final String[] objects = new String[ns];// = names;
			for (int i = 0; i<ns; ++i){
				objects[i] = names2.get(i).split("\\|")[0];
			}

			Intent I = new Intent(this, Activity_Locations.class);

			I.putExtra(Activity_Locations.skf_Caption, regions[index]);
			I.putExtra(Activity_Locations.skf_Items, objects);
			I.putExtra(Activity_Locations.skf_Selected, -1);
			startActivityForResult(I, 1);
			*/
	//		 Toast.makeText(getBaseContext(),m_Items[ItemIndex], Toast.LENGTH_SHORT).show();
/*		switch (v.getId()) {
		case  R.id.region_list1: {
			str="1";
			 dh = getDataHelper();
			 List<String> names2 = this.dh.selectAll333(str);
			 int ns=names2.size();
			 final String[] objects=new String[ns];// = names;
			 int s=0;
			 for (String name : names2) {
			    	 objects[s]=name;
			    	 s++;
			    }
			Intent I = new Intent(this, SKF_Listcheck2_Activity.class);

			I.putExtra(SKF_Listcheck2_Activity.skf_Caption,regionA);
			I.putExtra(SKF_Listcheck2_Activity.skf_Items,objects);
			I.putExtra(SKF_Listcheck2_Activity.skf_Selected,-1);
			startActivityForResult(I, 1);
			
			Intent I = new Intent(this, Activity_Locations.class);

			I.putExtra(Activity_Locations.skf_Caption, regions[index]);
			I.putExtra(Activity_Locations.skf_Items, objects);
			I.putExtra(Activity_Locations.skf_Selected, -1);
			startActivityForResult(I, 1);
			
			break;
	                   		}
		case  R.id.region_list2: {
			str="2";
			dh = getDataHelper();
			 List<String> names2 = this.dh.selectAll333(str);
			 int ns=names2.size();
			 final String[] objects=new String[ns];// = names;
			 int s=0;
			 for (String name : names2) {
			    	 objects[s]=name;
			    	 s++;
			    }
			Intent I = new Intent(this, SKF_Listcheck2_Activity.class);

			I.putExtra(SKF_Listcheck2_Activity.skf_Caption,regionB);
			I.putExtra(SKF_Listcheck2_Activity.skf_Items,objects);
			I.putExtra(SKF_Listcheck2_Activity.skf_Selected,-1);
			startActivityForResult(I, 2);
	
			
			break;
	                   		}
		case  R.id.region_list3: {
			str="3";
			dh = getDataHelper();
			 List<String> names2 = this.dh.selectAll333(str);
			 int ns=names2.size();
			 final String[] objects=new String[ns];// = names;
			 int s=0;
			 for (String name : names2) {
			    	 objects[s]=name;
			    	 s++;
			    }
			Intent I = new Intent(this, SKF_Listcheck2_Activity.class);

			I.putExtra(SKF_Listcheck2_Activity.skf_Caption,regionC);
			I.putExtra(SKF_Listcheck2_Activity.skf_Items,objects);
			I.putExtra(SKF_Listcheck2_Activity.skf_Selected,-1);
			startActivityForResult(I,3);
	
			break;
	                   		}
		case  R.id.region_list4: {
			str="4";
			dh = getDataHelper();
			 List<String> names2 = this.dh.selectAll333(str);
			 int ns=names2.size();
			 final String[] objects=new String[ns];// = names;
			 int s=0;
			 for (String name : names2) {
			    	 objects[s]=name;
			    	 s++;
			    }     
		*/
		switch (v.getId()) {
		case  R.id.region_list1: {
			str="1";
			 dh = getDataHelper();
			 List<String> names2 = this.dh.selectAll333(str);
			 int ns=names2.size();
			 final String[] objects=new String[ns];// = names;
			 int s=0;
			 for (String name : names2) {
			    	 objects[s]=name;
			    	 s++;
			    }
			
			Intent I = new Intent(this, Activity_Locations.class);
			I.putExtra(Activity_Locations.skf_Caption,regionA);
			I.putExtra(Activity_Locations.skf_Items, objects);
			I.putExtra(Activity_Locations.skf_Selected, -1);
			startActivityForResult(I, 1);
			break;
	                   		}
		case  R.id.region_list2: {
			str="2";
			dh = getDataHelper();
			 List<String> names2 = this.dh.selectAll333(str);
			 int ns=names2.size();
			 final String[] objects=new String[ns];// = names;
			 int s=0;
			 for (String name : names2) {
			    	 objects[s]=name;
			    	 s++;
			    }
				Intent I = new Intent(this, Activity_Locations.class);
			I.putExtra(Activity_Locations.skf_Caption,regionB);
			I.putExtra(Activity_Locations.skf_Items, objects);
			I.putExtra(Activity_Locations.skf_Selected, -1);
			startActivityForResult(I, 1);
	
			
			break;
	                   		}
		case  R.id.region_list3: {
			str="3";
			dh = getDataHelper();
			 List<String> names2 = this.dh.selectAll333(str);
			 int ns=names2.size();
			 final String[] objects=new String[ns];// = names;
			 int s=0;
			 for (String name : names2) {
			    	 objects[s]=name;
			    	 s++;
			    }
			
			Intent I = new Intent(this, Activity_Locations.class);
			I.putExtra(Activity_Locations.skf_Caption,regionC);
			I.putExtra(Activity_Locations.skf_Items, objects);
			I.putExtra(Activity_Locations.skf_Selected, -1);
			startActivityForResult(I, 1);
	
			
			break;
	                   		}
		case  R.id.region_list4: {
			str="4";
			dh = getDataHelper();
			 List<String> names2 = this.dh.selectAll333(str);
			 int ns=names2.size();
			 final String[] objects=new String[ns];// = names;
			 int s=0;
			 for (String name : names2) {
			    	 objects[s]=name;
			    	 s++;
			    }
			
			Intent I = new Intent(this, Activity_Locations.class);
			I.putExtra(Activity_Locations.skf_Caption,regionD);
			I.putExtra(Activity_Locations.skf_Items, objects);
			I.putExtra(Activity_Locations.skf_Selected, -1);
			startActivityForResult(I, 1);
	
			break;
	                   		}
			}	
		
		}
	}

