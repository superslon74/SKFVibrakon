package com.skf.vibracon.selection;

/*
 superslon74@gmail.com
 skype - superslon74
 schamanskij gennadij aleksandrovich
 */

import java.util.List;

import com.skf.style.SKF_list_controller;
import com.skf.style.SKF_list_controller.SKFListOnClickListener;
import com.skf.vibracon.selection.Activity_DeleteHistory;
import com.skf.vibracon.selection.Activity_Dillers;
import com.skf.vibracon.selection.Activity_SelectVibracon3;
import com.skf.vibracon.selection.DataHelper;
import com.skf.vibracon.selection.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class SKF_Listcheck4_Activity extends Activity implements
		SKFListOnClickListener {
	private DataHelper dh;
	String[] stroka = null;
	public final static String skf_Caption = "Caption";
	public final static String skf_Items = "Items";
	public final static String skf_Selected = "Selected";
public String number="4";
	protected SKF_list_controller m_ListControllerSM;
	protected SKF_list_controller m_ListControllerSMLP;
	protected int selected;
    String[] str1 = null;
	String[] str2 = null;

	String[] SMorSMLP(int a) {
		dh = getDataHelper();
		List<String> names2 = this.dh.selectAllTypVibraconSMorSMLP(a);
		int ns = names2.size();
		
		final String[] objects1 = new String[ns];// = names;
		final String[] objects2 = new String[ns];
		final String[] objects3 = new String[ns];

		int s2 = 0;
		for (String name : names2) {
			String str[] = name.split("\\|");

			objects1[s2] = str[0];
			objects2[s2] = str[1];
			s2++;
		}
		String met = dh.selectAll20();
		for (int i = 0; i < ns; i++) {
			// objects3[i]="|"+objects1[i]+"|";
			if (met.equals("0")) {
				objects3[i] = objects1[i] + "|" + objects2[i] + "|" + "kN|";
			} else {
				int n1 = (int) (Integer.parseInt(objects2[i].replaceAll(
						"[^0-9]", "")) * 100 * 0.2248);
				objects3[i] = objects1[i] + "|" + n1 + "|" + "lbf|";
			}
		}

		return objects3;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_skf_list_vibracons);
	((TextView) findViewById(R.id.skf_topbar_caption))
				.setText(getCaption());
		dh = getDataHelper();
		 String language=dh.selectLanguage();
		    String[] names = { LanguageTools.standart_3dmodel_caption,
		    		LanguageTools.low_profile_3dmodel_caption};
		String[] values = LanguageTools.getStrings(this, language, names,1);
		((TextView) findViewById(R.id.sm))
		.setText(values[0]);
		((TextView) findViewById(R.id.smlp))
		.setText(values[1]);
		  
		
		
		
		selected = getSelected();

		m_ListControllerSM = new SKF_list_controller(getLayoutInflater(),
				(ViewGroup) findViewById(R.id.skf_listcheck_vibracons_sm), this);
		m_ListControllerSMLP = new SKF_list_controller(getLayoutInflater(),
				(ViewGroup) findViewById(R.id.skf_listcheck_vibracons_smlp),
				this);
		
		str1=createList(SMorSMLP(1), m_ListControllerSM);
		str2=createList(SMorSMLP(2), m_ListControllerSMLP);
	}

	public DataHelper getDataHelper() {
		return new DataHelper(this);
	}

	protected String getCaption() {
		final Intent I = getIntent();
		return (I.hasExtra(skf_Caption)) ? I.getStringExtra(skf_Caption) : "";
	}

	protected int getSelected() {
		final Intent I = getIntent();
		return I.getIntExtra(skf_Selected, -1);
	}

	protected String[] getItems() {
		final Intent I = getIntent();
		return I.getStringArrayExtra(skf_Items);
	}

	protected String[] createList(String[] items, SKF_list_controller m_List) {
		LayoutInflater li = getLayoutInflater();
		final int len = items.length;
		  for (int i = 0; i < len; ++i) {
				   View item = li.inflate(R.layout.skf_listcheck_item, null);
				   // item.setOnClickListener((OnClickListener)this);
				   TextView text = (TextView) item
				     .findViewById(R.id.skf_listcheck_item_caption);
				   ImageView img = (ImageView) item
				     .findViewById(R.id.skf_listcheck_item_check);
				   img.setImageResource(R.drawable.skf_menu_item_arrow_selector);
				   img.setVisibility(View.VISIBLE);
				   String str[] = items[i].split("\\|");
				   text.setText(str[0]);
				   m_List.addView(item);
				  }
		
		m_List.createList();
		return items;
	}

	protected void onItemCustomized(int position, View item, TextView text,
			ImageView img) {
	}

	protected void doClick1(int ItemIndex) {

		String str[] = str1[ItemIndex].split("\\|");
		Intent intent2 = new Intent(getApplicationContext(),
				Activity_SelectVibracon3.class);
		intent2.putExtra("selectmachinen1", str[0]);
		intent2.putExtra("selectmachinen2", str[1]);

		startActivityForResult(intent2, 1);

	}

	protected void doClick2(int ItemIndex) {

		String str[] = str2[ItemIndex].split("\\|");
		Intent intent2 = new Intent(getApplicationContext(),
				Activity_SelectVibracon3.class);
		intent2.putExtra("selectmachinen1", str[0]);
		intent2.putExtra("selectmachinen2", str[1]);

		startActivityForResult(intent2, 1);
	}

	public void SKF_OnListItemClick(View listContainer, View v, int ItemIndex) {
		switch (listContainer.getId()) { // <= this is it
		case R.id.skf_listcheck_vibracons_sm: {
			doClick1(ItemIndex);
			break;
		}
		case R.id.skf_listcheck_vibracons_smlp: {
			doClick2(ItemIndex);

			break;
		}
		}
	}


	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// Check which request we're responding to
		if (requestCode == 1) {
			if (resultCode == RESULT_OK) {
				Intent intent = getIntent();
			    
			String select=intent.getStringExtra("selectext");
			Intent intent2 = new Intent(getApplicationContext(),Activity_Vibracon.class);
			  intent2.putExtra("selecexit","12345");
			  //selectmachinen
			  setResult(Activity.RESULT_OK,intent2);
				finish();
			
				
			} else
			{
		/*		Intent intent = getIntent();
				String select=intent.getStringExtra("selectext");
				Intent intent2 = new Intent(getApplicationContext(),Activity_Vibracon.class);
				  intent2.putExtra("selecexit","12345");
				  //selectmachinen
				  setResult(Activity.RESULT_OK,intent2);
					finish();
				*/
				
				
			}
		
			
		}}
	
	
}