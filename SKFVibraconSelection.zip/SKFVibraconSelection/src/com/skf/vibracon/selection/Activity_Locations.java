package com.skf.vibracon.selection;

/*
 superslon74@gmail.com
 skype - superslon74
 schamanskij gennadij aleksandrovich
 */

import com.skf.style.SKF_Listarrow_Activity;
import com.skf.style.SKF_list_controller.SKFListOnClickListener;
import android.content.Intent;
import android.widget.Toast;

public class Activity_Locations extends SKF_Listarrow_Activity implements
		SKFListOnClickListener {
	private String[] m_Items;
	
	@Override
	protected void createList(String[] items) {
		m_Items = items;
		//String[] res = items.split("\\|");
		int dlitems=items.length;
		String[] items2=new String[dlitems];
		for(int a=0;a<dlitems;a++)
		{
			String items3=items[a];
			String[] res = items3.split("\\|");
			items2[a]=res[0];
		}
		//String[] res = items.split("\\|");
		super.createList(items2);
	};	
	
	@Override
	protected void doClick(int ItemIndex) {
		Intent I = new Intent(this, Activity_Dillers.class);
		I.putExtra("info", m_Items[ItemIndex]);
		startActivityForResult(I, 1);
		
     // Toast.makeText(getBaseContext(),m_Items[ItemIndex], Toast.LENGTH_SHORT).show();
        
	}
}
