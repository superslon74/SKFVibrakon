package com.skf.vibracon.selection;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.nio.channels.FileChannel;

import min3d.core.Object3d;
import min3d.core.Object3dContainer;
import min3d.core.RendererActivity;
import min3d.parser.IParser;
import min3d.parser.Parser;
import min3d.vos.Color4;
import min3d.vos.Light;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
//import android.util.LruCache;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.TextView;
import android.view.ViewGroup.LayoutParams;

public class LoadObjFile extends RendererActivity implements OnTouchListener {
	private final static float OBJECT_MAX_SIZE = 2.5f;
	boolean rotating = false;
	int prevSwipeY, swipeY;
	int prevSwipeX, swipeX;
	int prevSwipeZ, swipeZ;
	final float ROTATION_SPEED_X = 2.0f;
	final float ROTATION_SPEED_Y = 2.75f;
	private float rot_x = 0, rot_y = 0;
	private ProgressDialog loading;

	int upPI = 0;
	int downPI = 0;
	boolean inTouch = false;
	public final static String RAWObjFileName = "RAWObjFilName";

	// private final Handler loadingComplete = new Handler() {
	// @Override
	// public void handleMessage(Message msg) {
	// loading.dismiss();
	// }
	// };

	private final Handler sceneUpdater = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			if ((null != msg.obj) && (msg.obj instanceof Object3dContainer)) {
				m_models[msg.what] = (Object3dContainer) msg.obj;
				doActivateTab(activeTab);
				if ((null != m_models[0]) && (null != m_models[1])) {
					loading.dismiss();
				}
			}
		}
	};

	static final int btnCount = 2;

	static Button m_Tabs[];
	private int activeTab = 0;
	private Object3dContainer m_models[] = { null, null };

	private void initVars() {
		DataHelper dh = new DataHelper(this);

		m_Tabs[0] = (Button) findViewById(R.id.d3model_view_tab_1);
		m_Tabs[1] = (Button) findViewById(R.id.d3model_view_tab_2);

		String[] names = { LanguageTools.d3_model,
				LanguageTools.standart_3dmodel_caption,
				LanguageTools.low_profile_3dmodel_caption };
		String language = dh.selectLanguage();
		String[] values = LanguageTools.getStrings(this, language, names,1);

		loading = ProgressDialog.show(this, "Generating models",
				"Please wait...", false);

		((TextView) findViewById(R.id.d3model_view_topbar_caption))
				.setText(values[0]);
		m_Tabs[0].setText(values[1]);
		m_Tabs[1].setText(values[2]);
	}

	public boolean onTouch(View v, MotionEvent event) {
		int page_ind = -1;
		int v_Id = v.getId();
		for (int i = 0; i < btnCount; ++i) {
			if (m_Tabs[i].getId() == v_Id) {
				page_ind = i;
				doActivateTab(page_ind);
				break;
			}
		}

		return (0 <= page_ind);
	}

	private void doActivateTab(int Index) {
		activeTab = Index;

		int cc = scene.numChildren();
		for (int i = 0; i < cc; ++i) {
			scene.removeChildAt(0);
		}

		for (int i = 0; i < btnCount; ++i) {
			m_Tabs[i].setPressed(Index == i);
			if ((Index == i) && (null != m_models[i])) {
				scene.addChild(m_models[i]);
			}

		}
		_glSurfaceView.invalidate();
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		((TextView) findViewById(R.id.d3model_view_topbar_caption))
				.setText(getIntent().getStringExtra(RAWObjFileName));
		m_Tabs = new Button[btnCount];
		m_models = new Object3dContainer[btnCount];

		initVars();

		for (int i = 0; i < btnCount; ++i) {
			m_Tabs[i].setOnTouchListener(this);
			m_Tabs[i].setPressed(false);
		}

		doActivateTab(0);
	}

	@Override
	public void onCreateSetContentView() {
		setContentView(R.layout.activity_3dmodel_view);
		((LinearLayout) findViewById(R.id.d3model_view_gl)).addView(
				_glSurfaceView, new LayoutParams(LayoutParams.MATCH_PARENT,
						LayoutParams.MATCH_PARENT));
	}

	private final class CoordinateAnalizer {
		public float MinValue;
		public float MaxValue;
		private boolean HasValue;

		public CoordinateAnalizer() {
			MinValue = 0;
			MaxValue = 0;
			HasValue = false;
		}

		public void AnalyzeValue(float v) {
			if (HasValue) {
				MaxValue = Math.max(MaxValue, v);
				MinValue = Math.min(MinValue, v);
			} else {
				MaxValue = v;
				MinValue = v;
				HasValue = true;
			}
		}

		public float Center() {
			return (MinValue + MaxValue) * 0.5f;
		}

		public float Size() {
			return MaxValue - MinValue;
		}
	}

	private class Object3dInitialization {
		public float xc = 0;
		public float yc = 0;
		public float zc = 0;
		public float maxSize = 0;
		public float scale = 1.0f;
		final public CoordinateAnalizer xa = new CoordinateAnalizer();
		final public CoordinateAnalizer ya = new CoordinateAnalizer();
		final public CoordinateAnalizer za = new CoordinateAnalizer();

		public void AnalyzeObject3d(Object3d obj) {
			FloatBuffer v_data = obj.vertices().points().buffer();
			int vl = obj.vertices().size() * 3;

			v_data.position(0);
			for (int i = 0; i < vl; i += 3) {
				xa.AnalyzeValue(v_data.get());
				ya.AnalyzeValue(v_data.get());
				za.AnalyzeValue(v_data.get());
			}
		}

		public void CalcInitParams() {
			xc = xa.Center();
			yc = ya.Center();
			zc = za.Center();
			maxSize = Math.max(Math.max(xa.Size(), ya.Size()), za.Size());
			scale = (maxSize > 0) ? OBJECT_MAX_SIZE / maxSize : 1.0f;
		}

		public void InitializeObject3d(Object3d obj) {
			FloatBuffer v_data = obj.vertices().points().buffer();
			int vl = obj.vertices().size() * 3;

			float coords[] = new float[3];
			for (int i = 0; i < vl; i += 3) {
				v_data.position(i);
				v_data.get(coords, 0, 3);
				coords[0] = (coords[0] - xc) * scale;
				coords[1] = (coords[1] - yc) * scale;
				coords[2] = (coords[2] - zc) * scale;
				v_data.position(i);
				v_data.put(coords, 0, 3);
			}

			obj.position().setAll(0, 0, 0);
			obj.vertexColorsEnabled(false);
			obj.colorMaterialEnabled(true);
			obj.material_ambient(new Color4(50, 50, 75, 255));
			obj.material_diffuse(new Color4(205, 200, 190, 255));
			obj.material_specular(new Color4(100, 120, 140, 255));
			obj.material_shininess(40f);

		}
	}

	@Override
	public void initScene() {

		final int ambient = 0x40;
		final int diffuse = 0xFF;
		final int specular = 0x80;
		scene.backgroundColor().setAll(0xF6, 0xF6, 0xF6, 0xFF);

		Light l = new Light();
		Light l2 = new Light();

		l.ambient.setAll(ambient, ambient, ambient, 0xFF);
		l.diffuse.setAll(diffuse, diffuse, diffuse, 0xFF);
		l.specular.setAll(0, 0, 0, 0);
		l.position.setAll(2, 0, 5);
		l.direction.setAll(-2, 0, -5);

		l2.ambient.setAll(0, 0, 0, 0);
		l2.diffuse.setAll(0, 0, 0, 0);
		l2.specular.setAll(specular, specular, specular, 0xFF);
		l2.position.setAll(-5, 0, 5);
		l2.direction.setAll(5, 0, -5);

		scene.lights().add(l);
		scene.lights().add(l2);

		(new Thread(new Runnable() {
			public void run() {
				Message msg0 = new Message();
				msg0.what = 0;
				msg0.obj = createObject("camaro_obj");
				sceneUpdater.sendMessage(msg0);
			}
		})).start();

		(new Thread(new Runnable() {
			public void run() {
				Message msg1 = new Message();
				msg1.what = 1;
				msg1.obj = createObject("camaro2_obj");
				sceneUpdater.sendMessage(msg1);
			}
		})).start();
	}

	private void writeInt(FileChannel fc, int data) {
		ByteBuffer bdata = ByteBuffer.allocateDirect(4);
		bdata.order(ByteOrder.nativeOrder());
		bdata.asIntBuffer().put(data);
		try {
			fc.write(bdata);
		} catch (IOException e) {
			e.printStackTrace();
		}
		bdata.clear();
	}

	private void writeFloatBuffer(FileChannel fc, FloatBuffer data) {
		int size = (null == data) ? 0 : data.limit();

		writeInt(fc, size);

		if (0 != size) {

			ByteBuffer bdata = ByteBuffer.allocateDirect(size * 4);
			bdata.order(ByteOrder.nativeOrder());
			data.position(0);
			bdata.asFloatBuffer().put(data);

			try {
				fc.write(bdata);
			} catch (IOException e) {
				e.printStackTrace();
			}
			bdata.clear();
		}
	}

	private void writeShortBuffer(FileChannel fc, ShortBuffer data) {
		int size = (null == data) ? 0 : data.limit();

		writeInt(fc, size);

		if (0 != size) {

			ByteBuffer bdata = ByteBuffer.allocateDirect(size * 2);
			bdata.order(ByteOrder.nativeOrder());
			data.position(0);
			bdata.asShortBuffer().put(data);

			try {
				fc.write(bdata);
			} catch (IOException e) {
				e.printStackTrace();
			}
			bdata.clear();
		}
	}

	private int readInt(FileChannel fc) {
		int res = 0;
		ByteBuffer bdata = ByteBuffer.allocateDirect(4);
		bdata.order(ByteOrder.nativeOrder());
		try {
			fc.read(bdata);
			bdata.position(0);
			res = bdata.getInt();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return res;
	}

	private void readFloatBuffer(FileChannel fc, FloatBuffer data) {
		int size = readInt(fc);
		ByteBuffer bdata = null;
		if (size > 0) {
			bdata = ByteBuffer.allocateDirect(size * 4);
			bdata.order(ByteOrder.nativeOrder());
			try {
				fc.read(bdata);
			} catch (IOException e) {
				bdata.clear();
				bdata = null;
				e.printStackTrace();
			}
			bdata.position(0);
			data.position(0);
			data.put(bdata.asFloatBuffer());
		}
	}

	private void readShortBuffer(FileChannel fc, ShortBuffer data) {
		int size = readInt(fc);
		ByteBuffer bdata = null;
		if (size > 0) {
			bdata = ByteBuffer.allocateDirect(size * 2);
			bdata.order(ByteOrder.nativeOrder());
			try {
				fc.read(bdata);
			} catch (IOException e) {
				bdata.clear();
				bdata = null;
				e.printStackTrace();
			}
			bdata.position(0);
			data.position(0);
			data.put(bdata.asShortBuffer());
		}
	}

	private Object3dContainer createObject(String filename) {
		File model_f = new File(getCacheDir(), filename);
		Object3dContainer obj = null;
		if (model_f.exists()) {

			obj = new Object3dContainer();

			FileInputStream fs = null;

			try {
				fs = new FileInputStream(model_f);

				if (null != fs) {
					FileChannel fc = fs.getChannel();

					int nc = readInt(fc);

					for (int i = 0; i < nc; ++i) {
						int v_cap = readInt(fc);
						int f_cap = readInt(fc);

						Object3d o = new Object3d(v_cap, f_cap);
						obj.addChild(o);
						o.points().setNumElements(v_cap);
						o.normals().setNumElements(v_cap);
						o.faces().setNumElements(f_cap);
						readFloatBuffer(fc, o.points().buffer());
						readFloatBuffer(fc, o.normals().buffer());
						readShortBuffer(fc, o.faces().buffer());
					}

					fc.close();
					fs.close();

				}

			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

		} else {

			String fileName = "com.skf.vibracon.selection:raw/" + filename;

			IParser parser = Parser.createParser(Parser.Type.OBJ,
					getResources(), fileName, false);
			parser.parse();

			obj = parser.getParsedObject();

			FileOutputStream fs = null;

			try {
				fs = new FileOutputStream(model_f, false);
				if (null != fs) {
					FileChannel fc = fs.getChannel();

					int nc = obj.numChildren();
					writeInt(fc, nc);
					for (int i = 0; i < nc; ++i) {
						Object3d o = obj.getChildAt(i);
						writeInt(fc, o.vertices().capacity());
						writeInt(fc, o.faces().capacity());
						writeFloatBuffer(fc, o.points().buffer());
						writeFloatBuffer(fc, o.normals().buffer());
						writeShortBuffer(fc, o.faces().buffer());
					}

					fc.close();
					fs.close();
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}

		if (null == obj) {
			// Create empty object
			obj = new Object3dContainer();
		}

		Object3dInitialization obj_init = new Object3dInitialization();
		int obj_cnt = obj.numChildren();

		obj_init.AnalyzeObject3d(obj);
		for (int i = 0; i < obj_cnt; ++i) {
			obj_init.AnalyzeObject3d(obj.getChildAt(i));
		}

		obj_init.CalcInitParams();

		obj_init.InitializeObject3d(obj);
		for (int i = 0; i < obj_cnt; ++i) {
			obj_init.InitializeObject3d(obj.getChildAt(i));
		}

		return obj;
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		int actionMask = event.getActionMasked();
		// ������ �������
		int pointerIndex = event.getActionIndex();
		// ����� �������
		int pointerCount = event.getPointerCount();

		switch (actionMask) {
		case MotionEvent.ACTION_DOWN: // ������ �������
			inTouch = true;
		case MotionEvent.ACTION_POINTER_DOWN: // ����������� �������

			if (pointerCount > 1) {
				downPI = pointerIndex;
				prevSwipeY = swipeY = 0; // for the Y axis
				prevSwipeX = swipeX = 0; // for the X axis

				rot_x = 0;
				rot_y = 0;
			}
			break;

		case MotionEvent.ACTION_UP: // ���������� ���������� �������
			inTouch = false;

		case MotionEvent.ACTION_POINTER_UP: // ���������� �������
			upPI = pointerIndex;
			break;

		case MotionEvent.ACTION_MOVE: // ��������
			float directionY = -(prevSwipeY - event.getX());
			float directionX = -(prevSwipeX - event.getY());
			View root = _glSurfaceView.getRootView();
			swipeY = (int) (directionY / root.getHeight() * 360 * ROTATION_SPEED_Y);
			swipeX = (int) (directionX / root.getWidth() * 180 * ROTATION_SPEED_X);
			break;
		}

		// Camera pivot point is different
		prevSwipeY = (int) event.getX();
		prevSwipeX = (int) event.getY();
		return super.onTouchEvent(event);
	}

	private float fixAngleX(float angle) {
		float angleLimit = (float) 90.0f;
		float res = angle;
		if (res > angleLimit) {
			res = angleLimit;
		} else {
			if (res < -angleLimit) {
				res = -angleLimit;
			}
		}
		return res;
	}

	private float fixAngleY(float angle) {
		float res = angle;
		while (res > 180.0f) {
			res -= 360.0f;
		}
		while (res < -180.0f) {
			res += 360.0f;
		}
		return res;
	}

	@Override
	public void updateScene() {
		if (swipeY != 0) // and we did swiped in the correct direction
			rot_y = fixAngleY(rot_y + swipeY);

		swipeY = 0; // Reset the pointer

		if (swipeX != 0) // and we did swiped in the correct direction
			rot_x = fixAngleX(rot_x + swipeX);

		swipeX = 0; // Reset the pointer

		for (int i = 0; i < btnCount; ++i) {
			if (null != m_models[i]) {
				m_models[i].rotation().x = rot_x;
				m_models[i].rotation().y = rot_y;
			}
		}

		try {
			Thread.sleep((scene.numChildren() > 0) ? 25 : 250);
		} catch (Exception e) {

		}
	}
}
