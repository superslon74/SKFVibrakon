package com.skf.vibracon.selection;
/*
superslon74@gmail.com
skype - superslon74
schamanskij gennadij aleksandrovich
*/


import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.xmlpull.v1.XmlPullParser;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.skf.vibracon.selection.DataHelper;

public class Activity_DeleteHistory extends Activity implements OnClickListener  {
	protected Button button1;
	private DataHelper dh;
	private TextView deleteall_text,deleteitem_text;
	String info=null;
	String info2=null;
	protected void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
   super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_deletehistory);
    findViewById(R.id.deleteall).setOnClickListener(this);
    findViewById(R.id.deleteitem).setOnClickListener(this);
	
    deleteall_text = (TextView) findViewById(R.id.deleteall_text);
    deleteitem_text = (TextView) findViewById(R.id.deleteitem_text);
    
    Intent intent = getIntent();
    info = intent.getStringExtra("info");
   
    dh = getDataHelper();

	String language=dh.selectLanguage();
    String[] names = { LanguageTools.remove_all,LanguageTools.view_order};
	String[] values = LanguageTools.getStrings(this, language, names,1);
	
	String[] model=info.split("\\|");
	((TextView) findViewById(R.id.contact_topbar_caption))
 	.setText(model[1]);
   
	
	deleteall_text.setText(values[0]);
	deleteitem_text.setText(values[1]);
	
	}

	  public DataHelper getDataHelper(){
		  	return new DataHelper(this);
		  }	
	  
	  public void onClick(View v){
		  switch (v.getId()) {
			case R.id.deleteall: {
				dh.deleteallhistory();
//				Toast.makeText(this, names2, Toast.LENGTH_SHORT).show();
				Intent I=new Intent();
				setResult(RESULT_OK,I);
			finish();
				
			
				break;
		                     }
            case R.id.deleteitem: {
            	String[] st=info.split("\\|");
	          	info2=st[0]+"|"+st[1]+"|"+st[2]+"|"+st[3]+"|"+st[4]+"|"+st[5]+"|"+st[6]+"|";  
	          Intent intent2 = new Intent(getApplicationContext(),Activity_SelectVibracon4.class);
	  		  intent2.putExtra("selectmachinen",info2);
	  		 startActivityForResult(intent2,1);
	  		// finish();
				break;
				                 }
		  
		  
		  }
		   	}
	  
	  protected void onActivityResult(int requestCode, int resultCode, Intent data) {
			// Check which request we're responding to
			if (requestCode == 1) {
				if (resultCode == RESULT_OK) {
  
	  Intent I=new Intent();
		setResult(RESULT_OK,I);
	finish();
	  
				}}}
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
 	@Override
	public void onConfigurationChanged(Configuration newConfig) {  
	        super.onConfigurationChanged(newConfig);  
	}	
 	
 	
}