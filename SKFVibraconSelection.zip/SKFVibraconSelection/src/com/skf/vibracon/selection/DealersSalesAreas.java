package com.skf.vibracon.selection;

import android.content.Intent;

import com.skf.style.SKF_Listarrow_Activity;

public class DealersSalesAreas extends SKF_Listarrow_Activity {

	@Override
	protected void doClick(int ItemIndex){
		Intent I = new Intent(this, DealersLocations.class);		
		I.putExtra(DealersLocations.LocationID, ItemIndex);
		startActivity(I);
	}
	
	@Override
	protected String getCaption() {
		return "Sales areas";
	}

	@Override
	protected String[] getItems() {
		String[] res = {"Asia", "Europe", "America"};
		return res;
	}
	
}
