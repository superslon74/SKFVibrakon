package com.skf.vibracon.selection;

import com.skf.style.SKF_Listarrow_Activity;

public class DealersLocations extends SKF_Listarrow_Activity {
	
	public final static String LocationID = "LocationsID";
	
	@Override
	protected void doClick(int ItemIndex) {
		// process click on country
	}

	@Override
	protected String getCaption() {
		return "Locations";
	}

	@Override
	protected String[] getItems() {
		String[] res = { "Kyev", "Paris", "London" };
		return res;
	}

}
