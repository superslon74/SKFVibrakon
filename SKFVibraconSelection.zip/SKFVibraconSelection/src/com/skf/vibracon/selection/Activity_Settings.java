package com.skf.vibracon.selection;

/*
 superslon74@gmail.com
 skype - superslon74
 schamanskij gennadij aleksandrovich
 */

/*
 superslon74@gmail.com
 skype - superslon74
 schamanskij gennadij aleksandrovich
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import com.skf.style.SKF_Listcheck_Activity;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class Activity_Settings extends Activity implements OnClickListener {
	final static int LegalInfoReqShowBack = 1;
	final static int LegalInfoReqShow = 2;
	final static int MeasurementsReq = 3;
	final static int LanguageReq = 4;
	final static int ContactInfo = 5;

	final String[] measurement_attribute = { LanguageTools.metric,
			LanguageTools.imperial};

	DataHelper dh;

	public void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_settings);
		
		findViewById(R.id.settings_contactinfo).setOnClickListener(this);
		findViewById(R.id.settings_measurmentunits).setOnClickListener(this);
		findViewById(R.id.settings_changelanguage).setOnClickListener(this);
		findViewById(R.id.settings_legalinformation).setOnClickListener(this);
		findViewById(R.id.settings_savebutton).setOnClickListener(this);

		dh = getDataHelper();

		updateCaptions(dh.selectLanguage());
	}

	public void updateCaptions(String language) {
		String[] names = { LanguageTools.contact_info,
				LanguageTools.measurment_units,
				measurement_attribute[dh.getMeasurementIndex()],
				LanguageTools.language, LanguageTools.language_name,
				LanguageTools.legal_information, LanguageTools.save_settings,
				LanguageTools.settings };
		String[] values = LanguageTools.getStrings(this, language, names,1);

		((TextView) findViewById(R.id.settings_contactinfo_caption))
				.setText(values[0]);
		((TextView) findViewById(R.id.settings_measurmentunits_caption))
				.setText(values[1]);
		((TextView) findViewById(R.id.settings_measurmentunits_value))
				.setText(values[2]);
		((TextView) findViewById(R.id.settings_changelanguage_caption))
				.setText(values[3]);
		((TextView) findViewById(R.id.settings_changelanguage_value))
				.setText(values[4]);
		((TextView) findViewById(R.id.settings_legalinformation_caption))
				.setText(values[5]);
		((Button) findViewById(R.id.settings_savebutton)).setText(values[6]);
		((TextView) findViewById(R.id.settings_topbar_caption))
				.setText(values[7]);

	}

	public DataHelper getDataHelper() {
		return new DataHelper(this);
	}

	public void onClick(View v) {
		switch (v.getId()) {
		case  R.id.settings_contactinfo: {
			Intent I = new Intent(getApplicationContext(),
					Activity_Contact.class);
			startActivity(I);
			break;
		}
		
		case R.id.settings_measurmentunits: {
			String language = dh.selectLanguage();
			Intent I = new Intent(this, SKF_Listcheck_Activity.class);

			I.putExtra(SKF_Listcheck_Activity.skf_Caption, LanguageTools
					.getString(this, language, LanguageTools.measurment_units));

			String[] names = { LanguageTools.metric, LanguageTools.imperial };
			I.putExtra(SKF_Listcheck_Activity.skf_Items,
					LanguageTools.getStrings(this, language, names,1));

			int Index = dh.getMeasurementIndex();
			I.putExtra(SKF_Listcheck_Activity.skf_Selected, Index);

			startActivityForResult(I, MeasurementsReq);
			break;
		}
		case R.id.settings_changelanguage: {
			String language = dh.selectLanguage();
			Intent I = new Intent(this, SKF_Listcheck_Activity.class);

			List<String> values = LanguageTools.getLanguages(this);
			int Index = values.indexOf(language);
			I.putExtra(SKF_Listcheck_Activity.skf_Selected, Index);

			String[] languages = new String[values.size()];
			values.toArray(languages);

			I.putExtra(SKF_Listcheck_Activity.skf_Items, languages);

			I.putExtra(SKF_Listcheck_Activity.skf_Caption, LanguageTools
					.getString(this, language, LanguageTools.language));

			startActivityForResult(I, LanguageReq);
			break;

		}
		case R.id.settings_legalinformation: {
			Intent intent22 = new Intent(getApplicationContext(),
					Activity_LegalInfo.class);
			startActivityForResult(intent22, LegalInfoReqShow);
			break;

		}
		case R.id.settings_savebutton: {
			dh = getDataHelper();
			String res = dh.select15();
			if (res.equals("1")) {
				dh.update16("1");
				goNext();
			} else {
				Intent I = new Intent(getApplicationContext(),
						Activity_LegalInfo.class);
				startActivityForResult(I, LegalInfoReqShowBack);
			}
			break;
		}

		
		default: {

			break;
		}
		}

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		switch (requestCode) {
		case MeasurementsReq: {
			if ((resultCode == RESULT_OK) && (null != data)) {
				int Index = data.getIntExtra(
						SKF_Listcheck_Activity.skf_Selected, -1);
				if (Index >= 0) {
					dh.setMeasurementIndex(Index);
					updateCaptions(dh.selectLanguage());
				}
			}
			break;

		}

		case LanguageReq: {
			if ((resultCode == RESULT_OK) && (null != data)) {
				int Index = data.getIntExtra(
						SKF_Listcheck_Activity.skf_Selected, -1);
				if (Index >= 0)
				{
					String language = LanguageTools.getLanguages(this).get(Index);
					dh.insertLanguage(language);
					updateCaptions(language);
				}

			}
			break;
		}

		case LegalInfoReqShowBack: {
			if (RESULT_OK == resultCode) {
				goNext();
			}
			break;
		}
		}

	}

	private void goNext() {
		Intent I = new Intent(getApplicationContext(), Activity_MainMenu.class);
		startActivity(I);
		finish();
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}

}
