package com.skf.vibracon.selection;

/*
 superslon74@gmail.com
 skype - superslon74
 schamanskij gennadij aleksandrovich
 */

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;

public class Activity_MainMenu extends Activity implements OnClickListener {
	private DataHelper dh;

	private final int request_settings = 1;
	private final int request_3dmodel = 2;
	private final int request_contacts = 3;
	private final int request_select_vibracon = 4;
	private final int request_history = 5;
	String[] values = null;
	String info = null;

	String language;

	public void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main_menu);

		final int bw = 640;
		final int bh = 409;
		int width = getWindowManager().getDefaultDisplay().getWidth();

		ImageView A = (ImageView) this.findViewById(R.id.mainmenu_top_image);
		A.getLayoutParams().height = (int) ((width * bh) / bw);

		findViewById(R.id.mainmenu_select_vibracon).setOnClickListener(this);
		findViewById(R.id.mainmenu_history).setOnClickListener(this);
		findViewById(R.id.mainmenu_3dmodel).setOnClickListener(this);
		findViewById(R.id.mainmenu_settings).setOnClickListener(this);
		findViewById(R.id.mainmenu_contacts).setOnClickListener(this);

		dh = getDataHelper();
		language = dh.selectLanguage();
		updateCaptions(language);
	}

	public void updateCaptions(String language) {
		String[] names = { LanguageTools.select_vibracon,
				LanguageTools.history, LanguageTools.d_model,
				LanguageTools.settings, LanguageTools.contacts };
		values = LanguageTools.getStrings(this, language, names,1);

		((TextView) findViewById(R.id.mainmenu_select_vibracon_caption))
				.setText(values[0]);
		((TextView) findViewById(R.id.mainmenu_history_caption))
				.setText(values[1]);
		((TextView) findViewById(R.id.mainmenu_3dmodel_caption))
				.setText(values[2]);
		((TextView) findViewById(R.id.mainmenu_settings_caption))
				.setText(values[3]);
		((TextView) findViewById(R.id.mainmenu_contacts_caption))
				.setText(values[4]);

	}

	public DataHelper getDataHelper() {
		return new DataHelper(this);
	}

	public void onClick(View v) {

		switch (v.getId()) {
		case R.id.mainmenu_settings: {
			startActivityForResult(new Intent(this, Activity_Settings.class),
					request_settings);
			break;
		}
		case R.id.mainmenu_3dmodel: {
			startActivityForResult(new Intent(this, LoadObjFile.class),
					request_3dmodel);
			break;
		}
		case R.id.mainmenu_contacts: {
			startActivityForResult(new Intent(this, Activity_Contact2.class),
					request_contacts);

			break;
		}
		case R.id.mainmenu_select_vibracon: {
			startActivityForResult(new Intent(this, Activity_Vibracon.class),
					request_select_vibracon);

			break;
		}
		case R.id.mainmenu_history: {

			startActivityForResult(new Intent(this, Activity_History.class),
					request_history);
			break;
		}

		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		switch (requestCode) {
		case request_settings: {
			updateCaptions(dh.selectLanguage());
			break;
		}

		}
	}
}
