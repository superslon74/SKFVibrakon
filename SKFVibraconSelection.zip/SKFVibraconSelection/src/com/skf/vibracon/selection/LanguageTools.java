package com.skf.vibracon.selection;
/*
superslon74@gmail.com
skype - superslon74
schamanskij gennadij aleksandrovich
*/

import java.util.ArrayList;
import java.util.List;

import org.xmlpull.v1.XmlPullParser;

import android.content.Context;

public class LanguageTools {
	public final static String machines="machines";
	public final static String fitterbolts="fitterbolts";
	public final static String standart_3dmodel_caption = "standart_3dmodel_caption";
	public final static String low_profile_3dmodel_caption = "low_profile_3dmodel_caption";
	public final static String d3_model = "d3_model";
	public final static String calculate_vibracon="calculate_vibracon";
	public final static String agree = "agree";
	public final static String name = "name";
	public final static String calculate = "calculate";
	public final static String cancel = "cancel";
	public final static String choice_of_base = "choice_of_base";
	public final static String company = "company";
	public final static String contact_info = "contact_info";
	public final static String contacts = "contacts";
	public final static String d_model = "d_model";
	public final static String dealers = "dealers";
	public final static String delete = "delete";
	public final static String diameter_of_bolt_hole = "diameter_of_bolt_hole";
	public final static String dry_weight = "dry_weight";
	public final static String email = "email";
	public final static String enter_characteristics = "enter_characteristics";
	public final static String from_database = "from_database";
	public final static String history = "history";
	public final static String imperial = "imperial";
	public final static String language = "language";
	public final static String language_name = "language_name";
	public final static String legal_information = "legal_information";
	public final static String machine_load = "machine_load";
	public final static String machine_type = "machine_type";
	public final static String machine_model = "machine_model";
	public final static String manufacturer = "manufacturer";
	public final static String measurment_units = "measurment_units";
	public final static String menu_order = "menu_order";
	public final static String metric = "metric";
	public final static String model = "model";
	public final static String nominal_power = "nominal_power";
	public final static String nominal_speed = "nominal_speed";
	public final static String number_of_bolt_holes = "number_of_bolt_holes";
	public final static String ok = "ok";
	public final static String owner_ship = "owner_ship";
	public final static String phone = "phone";
	public final static String privacy_policy = "privacy_policy";
	public final static String project = "project";
	public final static String remove_all = "remove_all";
	public final static String save = "save";
	public final static String save_settings = "save_settings";
	public final static String save_vibracon = "save_vibracon";
	public final static String select_bolt = "select_bolt";
	public final static String select_vibracon = "select_vibracon";
	public final static String settings = "settings";
	public final static String show = "show";
	public final static String start = "start";
	public final static String taga = "taga";
	public final static String tagb = "tagb";
	public final static String tagc = "tagc";
	public final static String terms_conditions = "terms_conditions";
	public final static String view_order = "view_order";
	public final static String visit_website = "visit_website";
	public final static String sales_areas="sales_areas";
	//public final static String language_name="language_name"; 
	public final static String africa="africa";
	public final static String americas="americas";
	public final static String asiapacific="asiapacific";
	public final static String europe="europe";		
	//public final static String model="Model";
	public final static String project_name="project_name";
	public final static String totalvibracons="totalvibracons";
	public final static String order_now="order_now";
	public final static String number_vibracon="number_vibracon";
	public final static String bolt_pitch="bolt_pitch";
	public static String[] getStrings(Context context, String ValuesLanguage,
			String[] names,int a) {
		int names_len = names.length;
		String[] values = new String[names_len];
		switch(a){
		case 1:
		try {
			XmlPullParser parser = context.getResources().getXml(R.xml.data);

			boolean parse_done = false;

			while ((parser.getEventType() != XmlPullParser.END_DOCUMENT)
					|| (!parse_done)) {
				if (parser.getEventType() == XmlPullParser.START_TAG
						&& parser.getName().equals("language")) {

					int attr_cnt = parser.getAttributeCount();

					for (int i = 0; i < attr_cnt; ++i) {
						if (language_name.equalsIgnoreCase(parser
								.getAttributeName(i))) {
							if (parser.getAttributeValue(i).equalsIgnoreCase(
									ValuesLanguage)) {
								parse_done = true;
								for (int attr_i = 0; attr_i < attr_cnt; ++attr_i) {
									String attr_name = parser
											.getAttributeName(attr_i);

									for (int name_i = 0; name_i < names_len; ++name_i) {
										if (attr_name
												.equalsIgnoreCase(names[name_i])) {
											values[name_i] = parser
													.getAttributeValue(attr_i);
											break;
										}
									}
								}
							}
							break;
						}
					}
				}
				parser.next();
			}
		} catch (Throwable t) {
		}
		
		case 2:{
			try {
				XmlPullParser parser = context.getResources().getXml(R.xml.region);

				boolean parse_done = false;

				while ((parser.getEventType() != XmlPullParser.END_DOCUMENT)
						|| (!parse_done)) {
					if (parser.getEventType() == XmlPullParser.START_TAG
							&& parser.getName().equals("language")) {

						int attr_cnt = parser.getAttributeCount();

						for (int i = 0; i < attr_cnt; ++i) {
							if (language_name.equalsIgnoreCase(parser
									.getAttributeName(i))) {
								if (parser.getAttributeValue(i).equalsIgnoreCase(
										ValuesLanguage)) {
									parse_done = true;
									for (int attr_i = 0; attr_i < attr_cnt; ++attr_i) {
										String attr_name = parser
												.getAttributeName(attr_i);

										for (int name_i = 0; name_i < names_len; ++name_i) {
											if (attr_name
													.equalsIgnoreCase(names[name_i])) {
												values[name_i] = parser
														.getAttributeValue(attr_i);
												break;
											}
										}
									}
								}
								break;
							}
						}
					}
					parser.next();
				}
			} catch (Throwable t) {
			}
		}
		
		case 3:{
			try {
				XmlPullParser parser = context.getResources().getXml(R.xml.selectvibracon);

				boolean parse_done = false;

				while ((parser.getEventType() != XmlPullParser.END_DOCUMENT)
						|| (!parse_done)) {
					if (parser.getEventType() == XmlPullParser.START_TAG
							&& parser.getName().equals("language")) {

						int attr_cnt = parser.getAttributeCount();

						for (int i = 0; i < attr_cnt; ++i) {
							if (language_name.equalsIgnoreCase(parser
									.getAttributeName(i))) {
								if (parser.getAttributeValue(i).equalsIgnoreCase(
										ValuesLanguage)) {
									parse_done = true;
									for (int attr_i = 0; attr_i < attr_cnt; ++attr_i) {
										String attr_name = parser
												.getAttributeName(attr_i);

										for (int name_i = 0; name_i < names_len; ++name_i) {
											if (attr_name
													.equalsIgnoreCase(names[name_i])) {
												values[name_i] = parser
														.getAttributeValue(attr_i);
												break;
											}
										}
									}
								}
								break;
							}
						}
					}
					parser.next();
				}
			} catch (Throwable t) {
			}
		}	
		}
		
		
		return values;
	}

	public static String getString(Context context, String ValuesLanguage,
			String attrib_name) {
		String value = "";
		try {
			XmlPullParser parser = context.getResources().getXml(R.xml.data);

			boolean parse_done = false;

			while ((parser.getEventType() != XmlPullParser.END_DOCUMENT)
					|| (!parse_done)) {
				if (parser.getEventType() == XmlPullParser.START_TAG
						&& parser.getName().equals("language")) {

					int attr_cnt = parser.getAttributeCount();

					for (int i = 0; i < attr_cnt; ++i) {
						if (language_name.equalsIgnoreCase(parser
								.getAttributeName(i))) {
							if (parser.getAttributeValue(i).equalsIgnoreCase(
									ValuesLanguage)) {
								parse_done = true;
								for (int attr_i = 0; attr_i < attr_cnt; ++attr_i) {
									if (parser.getAttributeName(attr_i).equals(
											attrib_name)) {
										value = parser
												.getAttributeValue(attr_i);
										break;
									}
								}
							}
							break;
						}
					}
				}
				parser.next();
			}
		} catch (Throwable t) {
		}
		return value;
	}

	public static List<String> getLanguages(Context context) {
		List<String> langs = new ArrayList<String>();

		try {
			XmlPullParser parser = context.getResources().getXml(R.xml.data);

			while (parser.getEventType() != XmlPullParser.END_DOCUMENT) {
				if (parser.getEventType() == XmlPullParser.START_TAG
						&& parser.getName().equals("language")) {

					int attr_cnt = parser.getAttributeCount();

					for (int i = 0; i < attr_cnt; ++i) {
						if (language_name.equalsIgnoreCase(parser
								.getAttributeName(i))) {
							langs.add(parser.getAttributeValue(i));
							break;
						}
					}
				}
				parser.next();
			}
		} catch (Throwable t) {
		}
		return langs;
	}
}
