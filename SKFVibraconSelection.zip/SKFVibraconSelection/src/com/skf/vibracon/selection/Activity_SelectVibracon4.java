package com.skf.vibracon.selection;

/*
 superslon74@gmail.com
 skype - superslon74
 schamanskij gennadij aleksandrovich
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.xmlpull.v1.XmlPullParser;

import com.skf.style.SKF_Listcheck_Activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Activity_SelectVibracon4 extends Activity implements
		OnClickListener {
	int as=0;
	private String email;
	private String letter;
	private DataHelper dh;
	private TextView spinner1;
	private TextView text1, text2, text4, text5,text6, text112, text122, text132,
			text21, text22, text9;
	private EditText text7, text11;
	private String modeller, maxload, sumorder, sumorder2;
	private Button button1, button2, button3, button4;
	public String selectmachinen = " not selected";
	public String selectmanufactorer = " not selected";
	public String model = " not selected";
	private String data1;
	private String status;
	private String id;
	private TextView textmodel, text10, text8, modelvalue, textmacload,textmacload2;
	Context mainContext;
	String[] values = null;
	private TableRow selectvibracon;
	private String buttona, buttonb, machineload, buttonc;

	List<String> getStringFromRawFile() throws IOException {
		List<String> list = new ArrayList<String>();
		InputStream inputStream = getResources().openRawResource(R.raw.select);
		InputStreamReader inputreader = new InputStreamReader(inputStream);
		BufferedReader buffreader = new BufferedReader(inputreader);

		String line;

		String text = new String("");
		// String[] text=null;
		int a;
		a = 0;
		while ((line = buffreader.readLine()) != null) {

			list.add(line);
		}
		return list;
	}

	protected void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_selectvibracon3);

		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

		dh = getDataHelper();
	
		textmodel = (TextView) findViewById(R.id.textmodel);
			text10 = (TextView) findViewById(R.id.text10);
		text8 = (TextView) findViewById(R.id.text8);
		text6 = (TextView) findViewById(R.id.text6);

		Intent intent = getIntent();
		selectmachinen = intent.getStringExtra("selectmachinen");

		String str = selectmachinen;// + selectmanufactorer+" \n "+model;
		String[] plot2 = str.split("\\|");
		data1 = plot2[0];
		status = plot2[4];
		id = plot2[6];
		String met = this.dh.selectAll20();
		String strt = "";
	
		String language = dh.selectLanguage();
		String[] names = { LanguageTools.model, LanguageTools.machine_load,
				LanguageTools.machine_type, LanguageTools.manufacturer,
				LanguageTools.machine_model, LanguageTools.project_name,
				LanguageTools.totalvibracons, LanguageTools.order_now,
				LanguageTools.save, LanguageTools.select_vibracon,
				LanguageTools.number_vibracon,LanguageTools.delete,LanguageTools.machines};
		values = LanguageTools.getStrings(this, language, names, 3);

		String[] namestab = { LanguageTools.select_vibracon };
		String[] values2 = LanguageTools
				.getStrings(this, language, namestab, 1);

		((TextView) findViewById(R.id.calcucate_vibracons)).setText(values2[0]);

		textmodel.setText(values[0]);
		machineload = values[1];
		text10.setText(values[5]);
		text8.setText(values[6]);
		buttona = values[7];
		buttonb = values[8];
		buttonc = values[11];

		button1 = (Button) findViewById(R.id.button1);
		selectvibracon = (TableRow) findViewById(R.id.selectnumbervibracon);
		selectvibracon.setOnClickListener(this);
		button4 = (Button) findViewById(R.id.button4);
		
		button3 = (Button) findViewById(R.id.button3);
		button1.setOnClickListener(this);
		button1.setText(buttona);
		button3.setOnClickListener(this);
		button3.setText(buttonb);
		button4.setOnClickListener(this);
		button4.setText(buttonc);
		text6.setText(values[12]);

		((TextView) findViewById(R.id.calcucate_vibracons)).setText(plot2[1]);

		if (met.equals("0")) {
				modelvalue = (TextView) findViewById(R.id.modelvalue);
			modelvalue.setText(plot2[1]);
			textmacload = (TextView) findViewById(R.id.textmacload);
			textmacload.setText("" + machineload);
			textmacload2= (TextView) findViewById(R.id.textmacload2);
			textmacload2.setText("" +plot2[5] + "kN");
				;
		} else {
			int n1 = (int) (Integer.parseInt(plot2[5].replaceAll("[^0-9]", "")) * 100 * 0.2248);
			modelvalue = (TextView) findViewById(R.id.modelvalue);
			modelvalue.setText(plot2[1]);
			textmacload = (TextView) findViewById(R.id.textmacload);
			textmacload.setText("" + machineload);
			textmacload2 = (TextView) findViewById(R.id.textmacload2);
			textmacload2.setText("" + n1 + "lbf");

		}

		text4 = (TextView) findViewById(R.id.text4);
		text5 = (TextView) findViewById(R.id.text5);
		text5.setText(plot2[2]);
		// text7=(EditText)findViewById(R.id.text7);
		text9 = (TextView) findViewById(R.id.text9);
		text11 = (EditText) findViewById(R.id.text11);
		text11.setText(plot2[3]);
		modeller = plot2[1];
		maxload = plot2[5];
		sumorder = plot2[2];
		sumorder2 = sumorder;
		text9.setText(sumorder);

		spinner1 = (TextView) this.findViewById(R.id.spinner1);
		
	}

	public DataHelper getDataHelper() {
		return new DataHelper(this);
	}

	private String[] selectnumbervibracon() {
		List<String> strts = null;
		try {
			strts = getStringFromRawFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int ns = strts.size();
		final String[] objects = new String[ns];// = names;

		int s = 0;
		for (String name : strts) {
			objects[s] = name;
			s++;
		}
		return objects;
	}

	public void onClick(View v) {

		dh = getDataHelper();
		if (v == selectvibracon) {

			Intent I = new Intent(this, SKF_Listcheck_Activity.class);
			I.putExtra(SKF_Listcheck_Activity.skf_Caption, values[10]);
			I.putExtra(SKF_Listcheck_Activity.skf_Items, selectnumbervibracon());
			I.putExtra(SKF_Listcheck_Activity.skf_Selected, as);
			startActivityForResult(I, 1);

		} else if (v == button1) {
				try {
				email = getStringFromRawFile1(Activity_SelectVibracon4.this);
				letter = getStringFromRawFile2(Activity_SelectVibracon4.this);
			} catch (IOException e) {
				e.printStackTrace();
			}

			String str = dh.selectAll12();

			if (str.equals("no registered user")) {

				Toast.makeText(this, "Contact Info must be filled!",
						Toast.LENGTH_SHORT).show();
			} else {

				String[] ss = str.split("\\|");
				String company = ss[0];
				String name = ss[1];
				String phone = ss[2];
				String email2 = ss[3];

				String letter2 = letter.replaceAll("Email", email2);
				String letter3 = letter2.replaceAll("Company", company);
				String letter4 = letter3.replaceAll("Name", name);
				String letter5 = letter4.replaceAll("Phone", phone);
				String letter6 = letter5.replaceAll("Modeller", modeller);
				String letter7 = letter6.replaceAll("Maxload", maxload);
				String letter8 = letter7.replaceAll("Sumorder", sumorder);
				String letter9 = letter8.replaceAll("Project", text11.getText()
						.toString());

				try {
					sender_mail_async async_sending = new sender_mail_async();
					async_sending.get(email, letter9);
					async_sending.execute();
				} catch (Exception e) {
				}

				int res = dh.insert5(modeller, maxload, sumorder, "send",
						text11.getText().toString());
				Intent intent2 = new Intent();
				setResult(Activity.RESULT_OK, intent2);

				finish();

				// Toast.makeText(this,modeller+" "+maxload+" "+sumorder,
				// Toast.LENGTH_SHORT).show();

			}
		} else if (v == button3) {

			String str = dh.selectAll12();
			if (str.equals("no registered user")) {

				Toast.makeText(this, "Contact Info must be filled!",
						Toast.LENGTH_SHORT).show();
			} else {

				int res = dh.insert5(modeller, maxload, sumorder, "save",
						text11.getText().toString());
				Intent intent3 = new Intent();
				setResult(Activity.RESULT_OK, intent3);

				finish();

			}
		} else 
			
			if (v == button4) {
//	 Toast.makeText(this,data1+" "+modeller+" "+sumorder+" "+text11.getText().toString()+" "+status+" "+maxload,
	// Toast.LENGTH_SHORT).show();

			dh.deletehistory(data1, modeller, sumorder, id, status, maxload);
			Intent intent3 = new Intent();
			setResult(Activity.RESULT_OK, intent3);

			finish();
		}

	}

	String getStringFromRawFile1(Activity activity) throws IOException {
		// "�������" �������
		Resources r = activity.getResources();
		// ������ -> ����� Inputstream

		InputStream inputStream = activity.getResources().openRawResource(
				R.raw.email);
		InputStreamReader inputreader = new InputStreamReader(inputStream);
		BufferedReader buffreader = new BufferedReader(inputreader);

		String line;

		String text = new String("");
		// String[] text=null;
		int a;
		a = 0;
		while ((line = buffreader.readLine()) != null) {

			text = line;
		}
		return text;
	}

	String getStringFromRawFile2(Activity activity) throws IOException {
		// "�������" �������
		Resources r = activity.getResources();
		// ������ -> ����� Inputstream

		InputStream inputStream = activity.getResources().openRawResource(
				R.raw.letter);
		InputStreamReader inputreader = new InputStreamReader(inputStream);
		BufferedReader buffreader = new BufferedReader(inputreader);

		String line;

		String text = new String("");
		// String[] text=null;
		int a;
		a = 0;
		while ((line = buffreader.readLine()) != null) {

			text = text + "\n" + line;
		}
		return text;
	}

	private class sender_mail_async extends AsyncTask<Object, String, Boolean> {
		ProgressDialog WaitingDialog;
		private String email, letter;

		public void get(String email, String letter) {
			this.email = email;
			this.letter = letter;

		}

		@Override
		protected void onPreExecute() {
			WaitingDialog = ProgressDialog.show(Activity_SelectVibracon4.this,
					"�������� ������", "���������� ���������...", true);
		}

		@Override
		protected void onPostExecute(Boolean result) {
			// WaitingDialog.dismiss();
			// Toast.makeText(mainContext, "�������� ���������!!!",
			// Toast.LENGTH_LONG).show();
			// ((Activity)mainContext).finish();
		}

		@Override
		protected Boolean doInBackground(Object... params) {

			try {
				MailSenderClass sender = new MailSenderClass(
						"skfvibraconselection@gmail.com", "20122112maya");
				sender.sendMail("sending the order", this.letter, this.email,
						this.email, "");
			} catch (Exception e) {
				Toast.makeText(mainContext, "������ �������� ���������!",
						Toast.LENGTH_SHORT).show();
			}

			return false;
		}
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// Check which request we're responding to
		if (requestCode == 1) {
			if (resultCode == RESULT_OK) {

				int as1 = data.getIntExtra(SKF_Listcheck_Activity.skf_Selected,
						-1);
				String[] numbervibracon = selectnumbervibracon();
				String selectnumbervibracon = numbervibracon[as1];
				spinner1.setText(selectnumbervibracon);
				sumorder = sumorder2;
				text9.setText(selectnumbervibracon);
				int a1 = Integer.parseInt(sumorder);
				int a2 = Integer.parseInt(selectnumbervibracon);
				int a3 = a1 * a2;
				text9.setText("" + a3);
				sumorder = "" + a3;
				as=as1;
			}
		}
	}
}
