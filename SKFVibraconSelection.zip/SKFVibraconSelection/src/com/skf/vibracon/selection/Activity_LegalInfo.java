package com.skf.vibracon.selection;

/*
 superslon74@gmail.com
 skype - superslon74
 schamanskij gennadij aleksandrovich
 */

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.xmlpull.v1.XmlPullParser;

import android.app.Activity;
import android.app.ProgressDialog;
import android.app.TabActivity;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

public class Activity_LegalInfo extends Activity implements OnTouchListener,
		OnClickListener {

	private DataHelper dh;

	static final int btnCount = 3;

	static View m_Tabs[];
	static View m_Pages[];

	private void initVars() {
		Button pli_tab_1, pli_tab_2, pli_tab_3, pli_button_agree;
		TextView pli_page_1, pli_page_2, pli_page_3;
		pli_page_1 = (TextView) findViewById(R.id.pli_page_1);
		pli_page_2 = (TextView) findViewById(R.id.pli_page_2);
		pli_page_3 = (TextView) findViewById(R.id.pli_page_3);
		pli_tab_1 = (Button) findViewById(R.id.pli_tab_1);
		pli_tab_2 = (Button) findViewById(R.id.pli_tab_2);
		pli_tab_3 = (Button) findViewById(R.id.pli_tab_3);
		pli_button_agree = (Button) findViewById(R.id.pli_button_agree);
		dh = getDataHelper();
		String res = dh.select15();
		if (res.equals("1")) {
			pli_button_agree.setVisibility(View.GONE);
		}

		String[] names = { LanguageTools.legal_information, LanguageTools.tagb,
				LanguageTools.taga, LanguageTools.tagc,
				LanguageTools.privacy_policy, LanguageTools.terms_conditions,
				LanguageTools.owner_ship, LanguageTools.agree };
		String language = this.dh.selectLanguage();
		
		String[] values = LanguageTools.getStrings(this, language, names,1);
		((TextView)findViewById(R.id.pli_topbar_caption)).setText(values[0]);
		pli_tab_1.setText(values[1]);
		pli_tab_2.setText(values[2]);
		pli_tab_3.setText(values[3]);
		pli_page_1.setText(values[4]);
		pli_page_2.setText(values[5]);
		pli_page_3.setText(values[6]);
		((Button)findViewById(R.id.pli_button_agree)).setText(values[7]);
		

		m_Tabs[0] = pli_tab_1;
		m_Tabs[1] = pli_tab_2;
		m_Tabs[2] = pli_tab_3;
		m_Pages[0] = pli_page_1;
		m_Pages[1] = pli_page_2;
		m_Pages[2] = pli_page_3;
	}

	public boolean onTouch(View v, MotionEvent event) {
		int page_ind = -1;
		int v_Id = v.getId();
		for (int i = 0; i < btnCount; ++i) {
			if (m_Tabs[i].getId() == v_Id) {
				page_ind = i;
				doActivateTab(page_ind);
				break;
			}
		}

		return (0 <= page_ind);
	}

	private void doActivateTab(int Index) {
		for (int i = 0; i < btnCount; ++i) {
			m_Tabs[i].setPressed(Index == i);
			m_Pages[i].setVisibility((Index == i) ? View.VISIBLE : View.GONE);
		}
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_legal_info);
		m_Tabs = new View[btnCount];
		m_Pages = new View[btnCount];

		initVars();

		for (int i = 0; i < btnCount; ++i) {
			m_Tabs[i].setOnTouchListener(this);
			m_Tabs[i].setPressed(false);
			m_Pages[i].setVisibility(View.GONE);
		}

		doActivateTab(0);

		findViewById(R.id.pli_button_agree).setOnClickListener(this);
	}

	public DataHelper getDataHelper() {
		return new DataHelper(this);
	}

	public void onClick(View v) {
		if (v.getId() == R.id.pli_button_agree) {
			dh = getDataHelper();
			dh.update15("1");
			setResult(RESULT_OK);
			finish();
		}
	}
}