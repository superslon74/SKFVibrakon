package com.skf.vibracon.selection;

/*
superslon74@gmail.com
skype - superslon74
schamanskij gennadij aleksandrovich
*/


import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.xmlpull.v1.XmlPullParser;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.skf.vibracon.selection.DataHelper;

public class Activity_Contact2 extends Activity implements OnClickListener  {
	protected Button button1;
	private DataHelper dh;
	private TextView dealers,visit_website;
	
	protected void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
   super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_contact2);
    findViewById(R.id.dealers_list).setOnClickListener(this);
	findViewById(R.id.web).setOnClickListener(this);
	
    dealers = (TextView) findViewById(R.id.dealers);
    visit_website = (TextView) findViewById(R.id.visit_website);
  
    
    
    dh = getDataHelper();

	String language=dh.selectLanguage();
    String[] names = { LanguageTools.dealers,
			LanguageTools.visit_website,
			LanguageTools.contacts};
	String[] values = LanguageTools.getStrings(this, language, names,1);
 
	dealers.setText(values[0]);
	visit_website.setText(values[1]);
	((TextView) findViewById(R.id.contact_topbar_caption))
	.setText(values[2]);
   
  
  }
  public DataHelper getDataHelper(){
  	return new DataHelper(this);
  }


 	public void onClick(View v){
 		switch (v.getId()) {
		case  R.id.web: {
			String str="http://machinesupport.com/industry/products_vibracon.html";
			startActivity(new Intent(android.content.Intent.ACTION_VIEW,Uri.parse(str))); 	
			break;
	                   		}
		case  R.id.dealers_list: {
        	startActivityForResult(new Intent(this, Activity_Regions.class),1);
			break;
	                   		}
			}
		
	}
 	@Override
	public void onConfigurationChanged(Configuration newConfig) {  
	        super.onConfigurationChanged(newConfig);  
	}	
 	
 	
}