package com.skf.vibracon.selection;

/*
 superslon74@gmail.com
 skype - superslon74
 schamanskij gennadij aleksandrovich
 */

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.xmlpull.v1.XmlPullParser;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.skf.style.SKF_Listcheck_Activity;

import com.skf.vibracon.selection.DataHelper;
import android.graphics.Paint.Style;



public class Activity_Dillers extends Activity implements OnClickListener {

	private DataHelper dh;
	public TextView city_text1, adress_text1, phone_text, web_text, email_text;
	Button	map_text;
	String info = null;
	String[] res = null;
	TableRow email,web;
	protected void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_dillers);
		Intent intent = getIntent();
		info = intent.getStringExtra("info");
     // Toast.makeText(getBaseContext(), info, Toast.LENGTH_SHORT).show();
        
		
		res = info.split("\\|");

		dh = getDataHelper();
		String language = dh.selectLanguage();
		String[] names = { LanguageTools.contact_info };
		String[] values = LanguageTools.getStrings(this, language, names,1);
		((TextView) findViewById(R.id.contact_topbar_caption))
				.setText(values[0]);
		TableLayout table = (TableLayout)findViewById(R.id.boss);
		TableRow sity=(TableRow)findViewById(R.id.sity);
		TableRow phone2=(TableRow)findViewById(R.id.phone2);
	//	sity.setOnClickListener(this);
		//table.removeView(sity);
		TableRow web=(TableRow)findViewById(R.id.web);
		web.setOnClickListener(this);
		TableRow email=(TableRow)findViewById(R.id.email);
		email=(TableRow)findViewById(R.id.email);
		email.setOnClickListener(this);
		city_text1 = (TextView) findViewById(R.id.city_text1);
		city_text1.setText(res[0]);
		sity.setOnClickListener(this);
		adress_text1 = (TextView) findViewById(R.id.adress_text1);
		adress_text1.setText(res[1]);
		phone_text = (TextView) findViewById(R.id.phone_text);
		phone_text.setText(res[2]);
		web_text = (TextView) findViewById(R.id.web_text);
		email_text = (TextView) findViewById(R.id.email_text);
		email_text.setOnClickListener(this);
		email_text.setText("e-mail:");
	int length1=res[3].length();
	int length2=res[4].length();
	if(length1==0 && length2==0){
		table.removeView(web);
		table.removeView(email);
		phone2.setBackgroundResource(R.drawable.skf_menu_item_bottom);
		phone2.setPadding(25, 25, 25, 25);      
								}
	
		map_text = (Button) findViewById(R.id.map_text);
		map_text.setOnClickListener(this);
		map_text.setText("Show on map");
	//	map_text.setPaintFlags(map_text.getPaintFlags() |   Paint.UNDERLINE_TEXT_FLAG);
		
		
	}

	public DataHelper getDataHelper() {
		return new DataHelper(this);
	}

	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.web: {
			String str = "http://" + res[3];
			startActivity(new Intent(android.content.Intent.ACTION_VIEW,
					Uri.parse(str)));

			break;
		}
		case R.id.email: {
			Intent intent = new Intent(Intent.ACTION_SEND);
			intent.setType("plain/text");
			intent.putExtra(Intent.EXTRA_EMAIL, res[4]);
			intent.putExtra(Intent.EXTRA_SUBJECT, "");
			intent.putExtra(Intent.EXTRA_TEXT, "");
			startActivity(Intent.createChooser(intent,
					"Choice App to send email:"));
			break;
		}
		case R.id.map_text: {
			startActivity(new Intent(android.content.Intent.ACTION_VIEW,
					Uri.parse("geo:" + res[5] + "," + res[6] + "?q=" + res[5]
							+ "," + res[6] + "(" + "SKF" + ")")));

			break;
		}
		}
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}

}