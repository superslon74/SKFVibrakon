package min3d.parser;

public class ParseObjectFace {
	public int[] v;
	public int[] uv;
	public int[] n;
	public int faceLength;
	public boolean hasuv;
	public boolean hasn;
	public String materialKey;

}
