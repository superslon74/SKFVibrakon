package min3d.interfaces;
/*
superslon74@gmail.com
skype - superslon74
schamanskij gennadij aleksandrovich
*/
public interface IDirtyParent 
{
	public void onDirty();
}
