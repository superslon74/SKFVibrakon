package min3d;
/*
superslon74@gmail.com
skype - superslon74
schamanskij gennadij aleksandrovich
*/
public class Min3d 
{
	public static final String TAG = "Min3D";
	
	
}
